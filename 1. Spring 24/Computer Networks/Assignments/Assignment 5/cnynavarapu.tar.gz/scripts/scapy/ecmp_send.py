#!/usr/bin/env python3

import argparse
from scapy.all import IP, TCP, UDP, Ether, sendp
from random import randint, choice

random.seed(1234)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tcp', action='store_true', help='Send TCP packets')
    parser.add_argument('--udp', action='store_true', help='Send UDP packets')
    parser.add_argument('--rand', action='store_true', help='Randomly select TCP or UDP for each packet')
    parser.add_argument('--dst-ip', type=str, required=True, help='Destination IP address')
    parser.add_argument('--dst-port', type=int, required=True, help='Destination port number')
    parser.add_argument('--src-port', type=int, default=1234, help='Source port number (default: 1234)')
    parser.add_argument('--iface', type=str, default='eth0', help='Network interface to send packets (default: eth0)')
    parser.add_argument('--count', type=int, default=1, help='Number of packets to send (default: 1)')
    args = parser.parse_args()

    if args.rand:
        print(f"Sending {args.count} random packet(s) (TCP or UDP) to {args.dst_ip}:{args.dst_port}")
        for _ in range(args.count):
            protocol = choice(['tcp', 'udp'])
            src_port = randint(1024, 65535)
            dst_port = randint(1024, 65535)
            if protocol == 'tcp':
                pkt = Ether() / IP(dst=args.dst_ip) / TCP(sport=src_port, dport=dst_port)
            else:
                pkt = Ether(src="00:00:00:00:00:01", dst="00:00:00:00:01:01")/IP(src="192.168.0.10", dst=args.dst_ip) / UDP(sport=src_port, dport=dst_port)
            sendp(pkt, iface=args.iface, verbose=True)
    elif args.tcp:
        print(f"Sending {args.count} random TCP packet(s) to {args.dst_ip}:{args.dst_port}")
        for _ in range(args.count):
            src_port = randint(1024, 65535)
            dst_port = randint(1024, 65535)
            pkt = Ether(src="00:00:00:00:00:01", dst="00:00:00:00:01:01")/IP(src="192.168.0.10", dst=args.dst_ip) / TCP(sport=src_port, dport=dst_port)
            sendp(pkt, iface=args.iface, verbose=True)
    elif args.udp:
        print(f"Sending {args.count} random UDP packet(s) to {args.dst_ip}:{args.dst_port}")
        for _ in range(args.count):
            src_port = randint(1024, 65535)
            dst_port = randint(1024, 65535)
            pkt = Ether(src="00:00:00:00:00:01", dst="00:00:00:00:01:01")/IP(src="192.168.0.10", dst=args.dst_ip) / UDP(sport=src_port, dport=dst_port)
            sendp(pkt, iface=args.iface, verbose=True)
    else:
        print("Please specify either --tcp, --udp, or --rand")
        return

    print("Packet(s) sent successfully!")

if __name__ == '__main__':
    main()
