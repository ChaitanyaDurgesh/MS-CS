#!/bin/bash

scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config scripts/BMv2/run_bmv2_s1.sh ubuntu@[2001:400:a100:3040:f816:3eff:fe66:f1f5]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config rules/add_rules_s1.sh ubuntu@[2001:400:a100:3040:f816:3eff:fe66:f1f5]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config p4/s1.p4 ubuntu@[2001:400:a100:3040:f816:3eff:fe66:f1f5]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config scripts/BMv2/run_bmv2_s2.sh ubuntu@[2001:400:a100:3040:f816:3eff:fe0a:2804]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config rules/add_rules_s2.sh ubuntu@[2001:400:a100:3040:f816:3eff:fe0a:2804]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config p4/s2.p4 ubuntu@[2001:400:a100:3040:f816:3eff:fe0a:2804]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config scripts/BMv2/run_bmv2_s3.sh ubuntu@[2001:400:a100:3040:f816:3eff:fe26:ba6]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config rules/add_rules_s3.sh ubuntu@[2001:400:a100:3040:f816:3eff:fe26:ba6]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config p4/s3.p4 ubuntu@[2001:400:a100:3040:f816:3eff:fe26:ba6]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config scripts/BMv2/run_bmv2_s4.sh ubuntu@[2001:400:a100:3040:f816:3eff:fed9:6c9b]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config rules/add_rules_s4.sh ubuntu@[2001:400:a100:3040:f816:3eff:fed9:6c9b]:~
scp -i /home/fabric/work/fabric_config/Chaitanya_Durgesh_Silver -F /home/fabric/work/fabric_config/ssh_config p4/s4.p4 ubuntu@[2001:400:a100:3040:f816:3eff:fed9:6c9b]:~
