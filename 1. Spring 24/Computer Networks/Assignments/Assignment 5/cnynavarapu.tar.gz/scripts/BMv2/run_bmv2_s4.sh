#!/bin/bash

p4c --target bmv2 --arch v1model --std p4-16 ~/s4.p4 -o ~

sudo simple_switch -i 0@enp8s0 -i 1@enp9s0 -i 2@enp7s0 ~/s4.json --log-console