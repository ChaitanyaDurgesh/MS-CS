#!/bin/bash

simple_switch_CLI << _EOF_
table_add tunnel_table forward 1 => 3
_EOF_
