#!/bin/bash

simple_switch_CLI << _EOF_
table_add tunnel_table tunnel_forward 9 => fe:1b:26:e9:aa:21 1 8
_EOF_