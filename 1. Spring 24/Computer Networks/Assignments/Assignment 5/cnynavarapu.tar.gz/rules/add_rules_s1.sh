#!/bin/bash

simple_switch_CLI << _EOF_
table_add tunnel_table encapsulate 192.168.153.134/32 => c0:31:c8:6c:98:b2 0 9
_EOF_