#!/bin/bash

simple_switch_CLI << _EOF_
table_add tunnel_table forward 8 => f6:48:60:93:68:c9 2
_EOF_