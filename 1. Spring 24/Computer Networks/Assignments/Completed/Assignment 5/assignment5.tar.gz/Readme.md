# Assignment 5: Implementing Load-Balanced Custom Tunneling in P4

In this assignment, you will implement a custom tunneling protocol with ECMP load balancing in a given topology using P4 programming. The assignment consists of two parts:

## Part A: Implement Custom Tunneling Protocol

1. Modify the P4 program for switch `S1` (`s1.p4`) to encapsulate incoming IPv4 packets (both TCP and UDP) with a custom tunnel header. The custom tunnel header should include the following fields:
- `proto_id`: Protocol identifier for the custom tunnel header (should be assigned IPv4 protocol value)
- `dst_id`: Destination ID for the tunneled packet. All packets must be forwarded based on this field once the packet is tunnelled (encapsulated). Forward the encapsulated packets to either switch S2 or S3 based on the dst_id field.

The ethernet type of your custom header should be `0x1212`. Failing to add this will result in breaking tests during the run of auto grader.

2. Update the P4 programs for switches `S2` (`s2.p4`) and `S3` (`s3.p4`) to forward the encapsulated packets based on the `dst_id` field in the custom tunnel header. The forwarding logic should be similar for both switches, with the only difference being the specific table entries and output port values defined in the control plane.

3. Modify the P4 program for switch `S4` (`s4.p4`) to decapsulate the custom tunnel header and forward the original IPv4 packets to host `h2`. Update the parser to extract the custom tunnel header fields, the ingress processing to remove the custom header, and the deparser accordingly.

4. Add the necessary table rules for each switch in the corresponding `add_rules_s1.sh`, `add_rules_s2.sh`, `add_rules_s3.sh`, and `add_rules_s4.sh` files to achieve the desired forwarding behavior.

5. Run the "Custom Header Tunnel Forward Test" to verify the functionality of the custom tunneling protocol implementation.

> Note: Focus on correctly modifying the P4 programs (`s1.p4`, `s2.p4`, `s3.p4`, `s4.p4`) and the table rule files (`add_rules_s1.sh`, `add_rules_s2.sh`, `add_rules_s3.sh`, `add_rules_s4.sh`) for Part A.

## Part B: Implement ECMP Load Balancing (Bonus)

1. Extend the functionality of switch `S1` (`s1.p4`) to implement ECMP load balancing based on 5-tuple hashing for both TCP and UDP packets encapsulated with the custom tunnel header.

2. Modify the ingress processing of `s1.p4` to calculate the 5-tuple hash and use the hash result to determine the next-hop switch (`S2` or `S3`) for packet forwarding.

3. Update the table rules in `add_rules_s1.sh` to reflect the ECMP load balancing logic and ensure that the encapsulated packets are forwarded to the selected next-hop switch based on the hash result.

4. Run the "ECMP Load Balancing Test" to verify the functionality of the load balancing implementation.

> Note: For Part B, focus on modifying `s1.p4` and `add_rules_s1.sh`. The P4 programs for switches `S2`, `S3`, and `S4` will mostly remain unchanged from Part A except for the forwarding rules.

## Topology

The assignment uses the following topology:

<img src="./images/topology_diagram.png" width="700px"/>

- Host `h1` is connected to switch `S1`.
- Host `h2` is connected to switch `S4`.
- Switch `S1` is connected to switches `S2` and `S3`.
- Switches `S2` and `S3` are connected to switch `S4`.

Follow the provided instructions and test your implementation using the given test scripts and ensure that the custom tunneling protocol and ECMP load balancing function correctly based on the specified requirements.

## Setup Instructions

> Your specifications can be found at http://caper.cs.iit.edu/S24CS542/asgn5/_assignment5.txt, for example, if your student id was "jdoe", you'd go to http://caper.cs.iit.edu/S24CS542/asgn5/jdoe_assignment5.txt to fetch your config file.

To set up the assignment environment on FABRIC, follow these steps:

1. Transfer the `<your_hawk_uername>_assignment5.tar.gz` file to your FABRIC slice using a file upload or simply drag and drop.
2. Once the file is transferred, extract its contents using the following command:
   ```
   tar -xzf <your_hawk_uername>_assignment5.tar.gz
   ```
5. Navigate to the extracted `<your_hawk_id>_assignment5` directory:
   ```
   cd <your_hawk_uername>_assignment5
   ```
2. Download your `<your_hawk_username>_assignment5.txt` specfication file. Place it in the root `/` directory of assignment_5.
6. Follow the instructions provided in the assignment notebook to set up the topology, compile the P4 programs, and run the tests.
7. Modify the P4 programs (`p4/s1.p4`, `p4/s2.p4`, `p4/s3.p4`, `p4/s4.p4`) and table rule files (`rules/add_rules_s1.sh`, `rules/add_rules_s2.sh`, `rules/add_rules_s3.sh`, `rules/add_rules_s4.sh`) according to the assignment requirements.

4. Upload the `<your_hawk_id>_assignment5.tar.gz` file to the designated submission portal or as instructed by your course staff.

8. Test your implementation using the provided test cases after running each simulation and verify the functionality of the custom tunneling protocol and ECMP load balancing.

## Submission Instructions

First ensure all the cell outputs are saved in a notebook! Then only create a compressed tar file of the `<your_hawk_uername>_assignment5` folder using the following command:
```
tar -czf <your_hawk_uername>_assignment5.tar.gz <your_hawk_uername>_assignment5
```
or
```
zip -r <your_hawk_uername>_assignment5.tar.gz <your_hawk_uername>_assignment5
```

and upload it to blackboard.

## Grading

The notebook includes an autograder with comprehensive test cases to verify the correctness of your implementation. Please note that the score displayed by the autograder may not necessarily be your final grade. Your submission will be subject to manual review by the TAs to assess Correctness, Code Quality, Authenticity, Submission Date...

Please ensure that you thoroughly test your implementation using the provided test case and ensure you save the cell outputs. It is your responsibility to submit a well-tested and functional solution before deadline.

Good luck with the assignment! :)