#!/bin/bash

simple_switch_CLI << _EOF_

_EOF_
