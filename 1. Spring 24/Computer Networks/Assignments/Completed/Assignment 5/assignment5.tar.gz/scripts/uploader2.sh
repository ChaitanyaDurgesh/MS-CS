#!/bin/bash

scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config scripts/BMv2/run_bmv2_s1.sh ubuntu@[2001:400:a100:3020:f816:3eff:fe1a:43d]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config rules/add_rules_s1.sh ubuntu@[2001:400:a100:3020:f816:3eff:fe1a:43d]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config p4/s1.p4 ubuntu@[2001:400:a100:3020:f816:3eff:fe1a:43d]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config scripts/BMv2/run_bmv2_s2.sh ubuntu@[2001:400:a100:3020:f816:3eff:fe61:2894]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config rules/add_rules_s2.sh ubuntu@[2001:400:a100:3020:f816:3eff:fe61:2894]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config p4/s2.p4 ubuntu@[2001:400:a100:3020:f816:3eff:fe61:2894]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config scripts/BMv2/run_bmv2_s3.sh ubuntu@[2001:400:a100:3020:f816:3eff:fe8e:e9da]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config rules/add_rules_s3.sh ubuntu@[2001:400:a100:3020:f816:3eff:fe8e:e9da]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config p4/s3.p4 ubuntu@[2001:400:a100:3020:f816:3eff:fe8e:e9da]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config scripts/BMv2/run_bmv2_s4.sh ubuntu@[2001:400:a100:3020:f816:3eff:fe55:c45a]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config rules/add_rules_s4.sh ubuntu@[2001:400:a100:3020:f816:3eff:fe55:c45a]:~
scp -i /home/fabric/work/fabric_config/CS542_Silver_Key_Pair_Prajwal -F /home/fabric/work/fabric_config/ssh_config p4/s4.p4 ubuntu@[2001:400:a100:3020:f816:3eff:fe55:c45a]:~
