#!/usr/bin/env python3

import argparse
from scapy.all import sniff, IP, TCP, UDP

def packet_handler(pkt):
    if IP in pkt:
        src_ip = pkt[IP].src
        dst_ip = pkt[IP].dst
        proto = pkt[IP].proto

        if proto == 6 and TCP in pkt:
            src_port = pkt[TCP].sport
            dst_port = pkt[TCP].dport
            print(f"Received TCP packet: {src_ip}:{src_port} -> {dst_ip}:{dst_port}")
        elif proto == 17 and UDP in pkt:
            src_port = pkt[UDP].sport
            dst_port = pkt[UDP].dport
            print(f"Received UDP packet: {src_ip}:{src_port} -> {dst_ip}:{dst_port}")
        else:
            print(f"Received IP packet: {src_ip} -> {dst_ip}, Protocol: {proto}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--iface', type=str, default='enp7s0', help='Network interface to listen on (default: eth0)')
    parser.add_argument('--count', type=int, default=0, help='Number of packets to capture (default: 0, unlimited)')
    args = parser.parse_args()

    print(f"Listening for packets on interface: {args.iface}")
    sniff(iface=args.iface, count=args.count, prn=packet_handler)

if __name__ == '__main__':
    main()
