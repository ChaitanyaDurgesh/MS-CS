#!/bin/bash

p4c --target bmv2 --arch v1model --std p4-16 ~/s3.p4 -o ~

sudo simple_switch -i 0@enp7s0 -i 1@enp8s0 ~/s3.json --log-console