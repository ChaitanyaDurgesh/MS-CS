#include "btree_mgr.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "dberror.h"
#include "tables.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_KEYS 3  // Example max number of keys per node for demonstration
#define MAX_CHILDREN (MAX_KEYS + 1)

// BTree node structure
typedef struct BTreeNode {
    bool isLeaf;
    int numKeys;
    Value keys[MAX_KEYS];
    RID records[MAX_KEYS];
    struct BTreeNode *children[MAX_CHILDREN];
} BTreeNode;

// BTree management structure
typedef struct BTreeMgmtData {
    BTreeNode *root;
    int numNodes;
    int numEntries;
} BTreeMgmtData;

typedef struct MgmtInfo_btree_scan {
    RID *entries;           // Array of RIDs in sorted order
    int numEntries;         // Total number of entries in the array
    int currentPos;         // Current position in the entries array
} MgmtInfo_btree_scan;

// Helper function declarations
BTreeNode *createNode(bool isLeaf);
BTreeMgmtData *initBTreeMgmtData();
void splitChild(BTreeMgmtData *mgmt, BTreeNode *parent, int index, BTreeNode *child);
void insertNonFull(BTreeMgmtData *mgmt, BTreeNode *node, Value key, RID rid);
char *printNode(BTreeNode *node, int pos);
// Prototype for recursive delete function
bool deleteKeyRecursive(BTreeMgmtData *mgmt, BTreeNode *node, Value key);
// Prototype for underflow handling function
void handleUnderflow(BTreeMgmtData *mgmt, BTreeNode *parent, int index);


// Index Manager Functions
RC initIndexManager(void *mgmtData) {
    initStorageManager();
    return RC_OK;
}

RC shutdownIndexManager() {
    return RC_OK;
}

// B+-Tree Management Functions
RC createBtree(char *idxId, DataType keyType, int n) {
    SM_FileHandle fh;
    if (createPageFile(idxId) != RC_OK)
        return RC_IM_KEY_NOT_FOUND;

    openPageFile(idxId, &fh);
    BTreeMgmtData *tree = initBTreeMgmtData();
    tree->numNodes = 1; // Initialize to 1 for the root node
    tree->numEntries = 0;
    closePageFile(&fh);
    return RC_OK;
}

RC openBtree(BTreeHandle **tree, char *idxId) {
    *tree = (BTreeHandle *)malloc(sizeof(BTreeHandle));
    (*tree)->idxId = idxId;
    (*tree)->keyType = DT_INT;
    (*tree)->mgmtData = initBTreeMgmtData();
    return RC_OK;
}

RC closeBtree(BTreeHandle *tree) {
    free(tree->mgmtData);
    free(tree);
    return RC_OK;
}

RC deleteBtree(char *idxId) {
    return destroyPageFile(idxId);
}

// Access Information Functions
RC getNumNodes(BTreeHandle *tree, int *result) {
    *result = ((BTreeMgmtData *)tree->mgmtData)->numNodes;
    return RC_OK;
}

RC getNumEntries(BTreeHandle *tree, int *result) {
    *result = ((BTreeMgmtData *)tree->mgmtData)->numEntries;
    return RC_OK;
}

RC getKeyType(BTreeHandle *tree, DataType *result) {
    *result = tree->keyType;
    return RC_OK;
}

// Core B+-Tree Operations

// Insert Key
RC insertKey(BTreeHandle *tree, Value *key, RID rid) {
    BTreeMgmtData *mgmt = (BTreeMgmtData *)tree->mgmtData;
    BTreeNode *root = mgmt->root;
    printf("Inserting key: %d with RID (page: %d, slot: %d)\n", key->v.intV, rid.page, rid.slot);

    if (root->numKeys == MAX_KEYS) {
        printf("Root is full, splitting...\n");
        BTreeNode *newRoot = createNode(false);
        newRoot->children[0] = root;
        splitChild(mgmt, newRoot, 0, root);
        mgmt->root = newRoot;
        mgmt->numNodes++; // Increment node count when creating new root
        printf("New root created. Total nodes: %d\n", mgmt->numNodes);
    }

    insertNonFull(mgmt, mgmt->root, *key, rid);
    mgmt->numEntries++;
    printf("Inserted key %d with RID (page: %d, slot: %d) into the B+-tree\n", key->v.intV, rid.page, rid.slot);
    return RC_OK;
}


// Find Key
RC findKey(BTreeHandle *tree, Value *key, RID *result) {
    BTreeNode *node = ((BTreeMgmtData *)tree->mgmtData)->root;
    printf("Starting findKey for key: %d\n", key->v.intV);

    while (node != NULL) {
        int i = 0;
        printf("Searching in node with numKeys: %d\n", node->numKeys);
        for (int j = 0; j < node->numKeys; j++) {
            printf("  Key %d at position %d with RID (page: %d, slot: %d)\n",
                   node->keys[j].v.intV, j, node->records[j].page, node->records[j].slot);
        }

        while (i < node->numKeys && key->v.intV > node->keys[i].v.intV) {
            i++;
        }

        if (i < node->numKeys && key->v.intV == node->keys[i].v.intV) {
            *result = node->records[i];
            printf("Key found with RID (page: %d, slot: %d)\n", result->page, result->slot);
            return RC_OK;
        }

        if (node->isLeaf) {
            printf("Reached leaf node without finding key.\n");
            return RC_IM_KEY_NOT_FOUND;
        }

        node = node->children[i];
    }

    printf("Key not found in B+-tree.\n");
    return RC_IM_KEY_NOT_FOUND;
}


// Delete Key
// Delete Key function
RC deleteKey(BTreeHandle *tree, Value *key) {
    BTreeMgmtData *mgmt = (BTreeMgmtData *)tree->mgmtData;
    BTreeNode *root = mgmt->root;

    printf("Starting deleteKey for key: %d\n", key->v.intV);

    if (!deleteKeyRecursive(mgmt, root, *key)) {
        printf("Key %d not found for deletion.\n", key->v.intV);
        return RC_IM_KEY_NOT_FOUND;
    }

    // If root has no keys after deletion, adjust tree height if necessary
    if (root->numKeys == 0 && !root->isLeaf) {
        BTreeNode *oldRoot = root;
        mgmt->root = root->children[0];  // Promote child as new root
        free(oldRoot);
        mgmt->numNodes--;  // Reduce node count
    }

    printf("Deleted key %d from the B+-tree\n", key->v.intV);
    mgmt->numEntries--;
    return RC_OK;
}

// Recursive helper function to delete a key from a node
bool deleteKeyRecursive(BTreeMgmtData *mgmt, BTreeNode *node, Value key) {
    int i = 0;

    // Locate the first key >= the key to delete
    while (i < node->numKeys && key.v.intV > node->keys[i].v.intV) {
        i++;
    }

    // Case 1: Key found in leaf node
    if (i < node->numKeys && key.v.intV == node->keys[i].v.intV) {
        if (node->isLeaf) {
            // Shift keys and records to delete the key in a leaf node
            for (int j = i; j < node->numKeys - 1; j++) {
                node->keys[j] = node->keys[j + 1];
                node->records[j] = node->records[j + 1];
            }
            node->numKeys--;
            printf("Deleted key %d in leaf node\n", key.v.intV);
            return true;
        } else {
            // Case 2: Key found in internal node
            printf("Key found in internal node; handle internal node deletion\n");

            // Replace with predecessor (largest in left subtree) or successor (smallest in right subtree)
            if (node->children[i]->numKeys >= MAX_KEYS / 2) {
                BTreeNode *predecessor = node->children[i];
                while (!predecessor->isLeaf) {
                    predecessor = predecessor->children[predecessor->numKeys];
                }
                node->keys[i] = predecessor->keys[predecessor->numKeys - 1];
                node->records[i] = predecessor->records[predecessor->numKeys - 1];
                deleteKeyRecursive(mgmt, node->children[i], predecessor->keys[predecessor->numKeys - 1]);
            } else if (node->children[i + 1]->numKeys >= MAX_KEYS / 2) {
                BTreeNode *successor = node->children[i + 1];
                while (!successor->isLeaf) {
                    successor = successor->children[0];
                }
                node->keys[i] = successor->keys[0];
                node->records[i] = successor->records[0];
                deleteKeyRecursive(mgmt, node->children[i + 1], successor->keys[0]);
            } else {
                // If neither child can provide a replacement, merge children and delete recursively
                handleUnderflow(mgmt, node, i);
                deleteKeyRecursive(mgmt, node->children[i], key);
            }
            return true;
        }
    }

    // Case 3: Key not found in current node, proceed to child if not a leaf
    if (!node->isLeaf) {
        printf("Traversing to child at index %d for key %d\n", i, key.v.intV);
        bool deleted = deleteKeyRecursive(mgmt, node->children[i], key);

        // Handle underflow if the child node has too few keys
        if (node->children[i]->numKeys < MAX_KEYS / 2) {
            handleUnderflow(mgmt, node, i);
        }
        return deleted;
    }

    // Key was not found in the tree
    printf("Key %d not found in the tree for deletion.\n", key.v.intV);
    return false;
}

// Handle underflow in B+-tree nodes by merging or redistributing keys
void handleUnderflow(BTreeMgmtData *mgmt, BTreeNode *parent, int index) {
    BTreeNode *node = parent->children[index];
    BTreeNode *leftSibling = (index > 0) ? parent->children[index - 1] : NULL;
    BTreeNode *rightSibling = (index < parent->numKeys) ? parent->children[index + 1] : NULL;

    // Case 1: Borrow from left sibling if it has more than minimum keys
    if (leftSibling && leftSibling->numKeys > MAX_KEYS / 2) {
        // Shift keys in node to make space for parent key
        for (int i = node->numKeys; i > 0; i--) {
            node->keys[i] = node->keys[i - 1];
            node->records[i] = node->records[i - 1];
        }
        if (!node->isLeaf) {
            for (int i = node->numKeys + 1; i > 0; i--) {
                node->children[i] = node->children[i - 1];
            }
        }
        // Move the parent's key down and borrow left sibling's largest key
        node->keys[0] = parent->keys[index - 1];
        node->records[0] = parent->records[index - 1];
        parent->keys[index - 1] = leftSibling->keys[leftSibling->numKeys - 1];
        parent->records[index - 1] = leftSibling->records[leftSibling->numKeys - 1];

        if (!node->isLeaf) {
            node->children[0] = leftSibling->children[leftSibling->numKeys];
        }
        leftSibling->numKeys--;
        node->numKeys++;
    }
    // Case 2: Borrow from right sibling if it has more than minimum keys
    else if (rightSibling && rightSibling->numKeys > MAX_KEYS / 2) {
        node->keys[node->numKeys] = parent->keys[index];
        node->records[node->numKeys] = parent->records[index];
        if (!node->isLeaf) {
            node->children[node->numKeys + 1] = rightSibling->children[0];
        }
        parent->keys[index] = rightSibling->keys[0];
        parent->records[index] = rightSibling->records[0];

        for (int i = 0; i < rightSibling->numKeys - 1; i++) {
            rightSibling->keys[i] = rightSibling->keys[i + 1];
            rightSibling->records[i] = rightSibling->records[i + 1];
        }
        if (!rightSibling->isLeaf) {
            for (int i = 0; i < rightSibling->numKeys; i++) {
                rightSibling->children[i] = rightSibling->children[i + 1];
            }
        }
        rightSibling->numKeys--;
        node->numKeys++;
    }
    // Case 3: Merge with left or right sibling if they cannot lend keys
    else if (leftSibling) {
        // Move parent's key down to left sibling and merge
        leftSibling->keys[leftSibling->numKeys] = parent->keys[index - 1];
        leftSibling->records[leftSibling->numKeys] = parent->records[index - 1];

        for (int i = 0; i < node->numKeys; i++) {
            leftSibling->keys[leftSibling->numKeys + 1 + i] = node->keys[i];
            leftSibling->records[leftSibling->numKeys + 1 + i] = node->records[i];
        }
        if (!node->isLeaf) {
            for (int i = 0; i <= node->numKeys; i++) {
                leftSibling->children[leftSibling->numKeys + 1 + i] = node->children[i];
            }
        }
        leftSibling->numKeys += node->numKeys + 1;

        for (int i = index - 1; i < parent->numKeys - 1; i++) {
            parent->keys[i] = parent->keys[i + 1];
            parent->records[i] = parent->records[i + 1];
            parent->children[i + 1] = parent->children[i + 2];
        }
        parent->numKeys--;

        free(node);
    } else if (rightSibling) {
        // Move parent's key down to node and merge
        node->keys[node->numKeys] = parent->keys[index];
        node->records[node->numKeys] = parent->records[index];

        for (int i = 0; i < rightSibling->numKeys; i++) {
            node->keys[node->numKeys + 1 + i] = rightSibling->keys[i];
            node->records[node->numKeys + 1 + i] = rightSibling->records[i];
        }
        if (!node->isLeaf) {
            for (int i = 0; i <= rightSibling->numKeys; i++) {
                node->children[node->numKeys + 1 + i] = rightSibling->children[i];
            }
        }
        node->numKeys += rightSibling->numKeys + 1;

        for (int i = index; i < parent->numKeys - 1; i++) {
            parent->keys[i] = parent->keys[i + 1];
            parent->records[i] = parent->records[i + 1];
            parent->children[i + 1] = parent->children[i + 2];
        }
        parent->numKeys--;

        free(rightSibling);
    }

    // Adjust root if necessary
    if (parent == mgmt->root && parent->numKeys == 0) {
        mgmt->root = parent->children[0];
        free(parent);
        mgmt->numNodes--;
    }

    printf("Underflow handled at child index %d\n", index);
}

// Tree Scanning Functions

void addEntries(BTreeNode* node, MgmtInfo_btree_scan *scanInfo)
{
    int i;
    for (i = 0; i < node->numKeys; i++) {
        if (!node->isLeaf) {
            addEntries(node->children[i], scanInfo);
        }
        scanInfo->entries[scanInfo->numEntries++] = node->records[i];
    }
    if (!node->isLeaf) {
       addEntries(node->children[i], scanInfo);
    }
}

RC openTreeScan(BTreeHandle *tree, BT_ScanHandle **handle) {
    // Allocate memory for the scan handle
    *handle = (BT_ScanHandle *) malloc(sizeof(BT_ScanHandle));

    // Allocate memory for the scan state
    MgmtInfo_btree_scan *scanInfo = (MgmtInfo_btree_scan *) malloc(sizeof(MgmtInfo_btree_scan));
    scanInfo->numEntries = 0;
    scanInfo->currentPos = 0;

    int total_entries;
    getNumEntries(tree, &total_entries);
    scanInfo->entries = (RID *) malloc(total_entries * sizeof(RID));

    // Traverse to the leftmost leaf node
    BTreeNode *currentNode = ((BTreeMgmtData *) tree->mgmtData)->root;
    addEntries(currentNode, scanInfo);

    // Assign scan state to handle
    (*handle)->tree = tree;
    (*handle)->mgmtData = scanInfo;

    return RC_OK;
}

RC nextEntry(BT_ScanHandle *handle, RID *result) {
    // Retrieve the scan information
    MgmtInfo_btree_scan *scanInfo = (MgmtInfo_btree_scan *) handle->mgmtData;

    // Check if we have reached the end of the entries array
    if (scanInfo->currentPos >= scanInfo->numEntries) {
        return RC_IM_NO_MORE_ENTRIES;
    }

    // Retrieve the RID at the current position and advance the position
    *result = scanInfo->entries[scanInfo->currentPos];
    scanInfo->currentPos++;

    return RC_OK;
}

RC closeTreeScan(BT_ScanHandle *handle) {
    // Retrieve scan information
    MgmtInfo_btree_scan *scanInfo = (MgmtInfo_btree_scan *) handle->mgmtData;

    // Free the entries array and the scan info structure
    free(scanInfo->entries);
    free(scanInfo);

    // Free the scan handle itself
    free(handle);

    return RC_OK;
}

// Debug and Test Functions

char *printTree(BTreeHandle *tree) {
    BTreeMgmtData *mgmt = (BTreeMgmtData *)tree->mgmtData;
    if (mgmt->root == NULL) return NULL;
    char *output = malloc(1024);  // Allocate memory for tree string representation
    strcpy(output, "");            // Initialize as empty string
    // Recursive function to print nodes should be defined to format as "(pos)[pointer,key,pointer,...]"
    return output;
}

// Helper Functions

BTreeMgmtData *initBTreeMgmtData() {
    BTreeMgmtData *mgmtData = (BTreeMgmtData *)malloc(sizeof(BTreeMgmtData));
    mgmtData->root = createNode(true);
    mgmtData->numNodes = 1; // Initialize to 1 for the root node
    mgmtData->numEntries = 0;
    return mgmtData;
}

BTreeNode *createNode(bool isLeaf) {
    BTreeNode *node = (BTreeNode *)malloc(sizeof(BTreeNode));
    node->isLeaf = isLeaf;
    node->numKeys = 0;
    for (int i = 0; i < MAX_KEYS; i++) {
        node->keys[i].v.intV = -1;  // Initialize key values
        node->records[i].page = -1;  // Initialize RID page
        node->records[i].slot = -1;  // Initialize RID slot
        node->children[i] = NULL;
    }
    node->children[MAX_KEYS] = NULL;
    return node;
}

// Modify splitChild to ensure mgmt correctly tracks numNodes
void splitChild(BTreeMgmtData *mgmt, BTreeNode *parent, int index, BTreeNode *child) {
    printf("Splitting child node at index %d. Current total nodes: %d\n", index, mgmt->numNodes);

    // Create new node to hold keys and RIDs from the split
    BTreeNode *newNode = createNode(child->isLeaf);
    newNode->numKeys = MAX_KEYS / 2;

    // Copy second half of keys and RIDs from child to newNode
    for (int i = 0; i < newNode->numKeys; i++) {
        newNode->keys[i] = child->keys[i + MAX_KEYS / 2 + 1];
        newNode->records[i] = child->records[i + MAX_KEYS / 2 + 1];
        printf("Copying key %d with RID (page: %d, slot: %d) to new node\n",
               newNode->keys[i].v.intV, newNode->records[i].page, newNode->records[i].slot);
    }

    // If child is not a leaf, move child pointers as well
    if (!child->isLeaf) {
        for (int i = 0; i <= newNode->numKeys; i++) {
            newNode->children[i] = child->children[i + MAX_KEYS / 2 + 1];
        }
    }

    // Update the child node's key count after the split
    child->numKeys = MAX_KEYS / 2;

    // Insert the middle key and RID into the parent node at the specified index
    for (int i = parent->numKeys; i >= index + 1; i--) {
        parent->children[i + 1] = parent->children[i];
    }
    parent->children[index + 1] = newNode;

    for (int i = parent->numKeys - 1; i >= index; i--) {
        parent->keys[i + 1] = parent->keys[i];
        parent->records[i + 1] = parent->records[i];
    }
    parent->keys[index] = child->keys[MAX_KEYS / 2];
    parent->records[index] = child->records[MAX_KEYS / 2];  // Ensure middle key RID is copied correctly
    parent->numKeys++;

    // Update mgmt to reflect the new total node count
    mgmt->numNodes++;
    printf("New node created. Total nodes after splitChild: %d\n", mgmt->numNodes);
}


void insertNonFull(BTreeMgmtData *mgmt, BTreeNode *node, Value key, RID rid) {
    int i = node->numKeys - 1;

    if (node->isLeaf) {
        // Insert key into the correct position in the leaf node
        while (i >= 0 && key.v.intV < node->keys[i].v.intV) {
            node->keys[i + 1] = node->keys[i];
            node->records[i + 1] = node->records[i];
            i--;
        }
        node->keys[i + 1] = key;
        node->records[i + 1] = rid;
        node->numKeys++;
        printf("Inserted key %d with RID (page: %d, slot: %d) at position %d in leaf node\n",
               key.v.intV, rid.page, rid.slot, i + 1);
    } else {
        // Find the correct child to proceed with insertion
        while (i >= 0 && key.v.intV < node->keys[i].v.intV) {
            i--;
        }
        i++;

        // If the chosen child is full, split it
        if (node->children[i]->numKeys == MAX_KEYS) {
            printf("Child node at index %d is full, splitting child...\n", i);
            splitChild(mgmt, node, i, node->children[i]);

            // After splitting, the middle key will have moved up to this node, so we check again
            if (key.v.intV > node->keys[i].v.intV) {
                i++;
            }
        }
        // Insert key into the non-full child
        insertNonFull(mgmt, node->children[i], key, rid);
    }
}
