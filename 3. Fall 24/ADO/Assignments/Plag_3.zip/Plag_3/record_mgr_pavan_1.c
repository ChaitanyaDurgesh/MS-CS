#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "record_mgr.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"

typedef struct RecordManager {
    BM_PageHandle pageHandle;
    BM_BufferPool bufferPool;
    RID recordID;
    Expr *condition;
    int countTuples;
    int freePage;
    int countScan;
} RecordManager;

const int MAX_NUMBER_OF_PAGES = 100;
const int ATTRIBUTE_SIZE = 15;

RecordManager *rManager;

extern RC initRecordManager (void *mgmtData) {
    initStorageManager();
    return RC_OK;
}

extern RC shutdownRecordManager () {
	
	free(rManager);
    rManager = NULL;
    return RC_OK;
}

extern RC createTable (char *name, Schema *schema) {
    rManager = (RecordManager*) malloc(sizeof(RecordManager));
    initBufferPool(&rManager->bufferPool, name, MAX_NUMBER_OF_PAGES, RS_LRU, NULL);

    char info[PAGE_SIZE];
    char *pageHandle = info;
    int result, k;
    *(int*)pageHandle = 0;
    pageHandle = pageHandle + sizeof(int);
    *(int*)pageHandle = 1;
    pageHandle = pageHandle + sizeof(int);
    *(int*)pageHandle = schema->numAttr;
    pageHandle = pageHandle + sizeof(int);
    *(int*)pageHandle = schema->keySize;
    pageHandle = pageHandle + sizeof(int);
    for(k = 0; k < schema->numAttr; k++) {
        strncpy(pageHandle, schema->attrNames[k], ATTRIBUTE_SIZE);
        pageHandle = pageHandle + ATTRIBUTE_SIZE;
        *(int*)pageHandle = (int)schema->dataTypes[k];
        pageHandle = pageHandle + sizeof(int);
        *(int*)pageHandle = (int) schema->typeLength[k];
        pageHandle = pageHandle + sizeof(int);
    }
    SM_FileHandle fileHandle;
    if((result = createPageFile(name)) != RC_OK)
        return result;
    if((result = openPageFile(name, &fileHandle)) != RC_OK)
        return result;
    if((result = writeBlock(0, &fileHandle, info)) != RC_OK)
        return result;
    if((result = closePageFile(&fileHandle)) != RC_OK)
        return result;
    return RC_OK;
}

extern RC openTable (RM_TableData *rel, char *name) {
    SM_PageHandle pageHandle;
    int countAttributes, k;
    rel->mgmtData = rManager;
    rel->name = name;
    pinPage(&rManager->bufferPool, &rManager->pageHandle, 0);
    pageHandle = (char*) rManager->pageHandle.data;
    rManager->countTuples= *(int*)pageHandle;
    pageHandle = pageHandle + sizeof(int);
    rManager->freePage= *(int*) pageHandle;
    pageHandle = pageHandle + sizeof(int);
    countAttributes = *(int*)pageHandle;
    pageHandle = pageHandle + sizeof(int);
    Schema *schema;
    schema = (Schema*) malloc(sizeof(Schema));
    schema->numAttr = countAttributes;
    schema->attrNames = (char**) malloc(sizeof(char*) *countAttributes);
    schema->dataTypes = (DataType*) malloc(sizeof(DataType) *countAttributes);
    schema->typeLength = (int*) malloc(sizeof(int) *countAttributes);
    for(k = 0; k < countAttributes; k++)
        schema->attrNames[k]= (char*) malloc(ATTRIBUTE_SIZE);
    for(k = 0; k < schema->numAttr; k++) {
        strncpy(schema->attrNames[k], pageHandle, ATTRIBUTE_SIZE);
        pageHandle = pageHandle + ATTRIBUTE_SIZE;
        schema->dataTypes[k]= *(int*) pageHandle;
        pageHandle = pageHandle + sizeof(int);
        schema->typeLength[k]= *(int*)pageHandle;
        pageHandle = pageHandle + sizeof(int);
    }
    rel->schema = schema;
    unpinPage(&rManager->bufferPool, &rManager->pageHandle);
    forcePage(&rManager->bufferPool, &rManager->pageHandle);
    return RC_OK;
}

extern RC closeTable (RM_TableData *rel) {
    RecordManager *rManager = rel->mgmtData;
    shutdownBufferPool(&rManager->bufferPool);
    return RC_OK;
}

extern RC deleteTable (char *name) {
    destroyPageFile(name);
    return RC_OK;
}

int findFreeSlot(char *data, int recordSize) {
    int i, totalSpace = PAGE_SIZE / recordSize;

    for (i = 0; i < totalSpace; i++)
        if (data[i * recordSize] != '+')
            return i;
    return -1;
}

extern int getNumTuples (RM_TableData *rel) {
    RecordManager *rManager = rel->mgmtData;
    return rManager->countTuples;
}

extern RC insertRecord (RM_TableData *rel, Record *record) {
    RecordManager *rManager = rel->mgmtData;
    RID *recordID = &record->id;
    char *info, *pointerToSlots;
    int recordSize = getRecordSize(rel->schema);
    recordID->page = rManager->freePage;
    pinPage(&rManager->bufferPool, &rManager->pageHandle, recordID->page);
    info = rManager->pageHandle.data;
    recordID->slot = findFreeSlot(info, recordSize);
    while(recordID->slot == -1) {
        unpinPage(&rManager->bufferPool, &rManager->pageHandle);
        recordID->page++;
        pinPage(&rManager->bufferPool, &rManager->pageHandle, recordID->page);
        info = rManager->pageHandle.data;
        recordID->slot = findFreeSlot(info, recordSize);
    }
    pointerToSlots = info;
    markDirty(&rManager->bufferPool, &rManager->pageHandle);
    pointerToSlots = pointerToSlots + (recordID->slot * recordSize);
    *pointerToSlots = '+';
    memcpy(++pointerToSlots, record->data + 1, recordSize - 1);
    unpinPage(&rManager->bufferPool, &rManager->pageHandle);
    rManager->countTuples++;
    pinPage(&rManager->bufferPool, &rManager->pageHandle, 0);
    return RC_OK;
}

extern RC deleteRecord (RM_TableData *rel, RID id) {
    RecordManager *rManager = rel->mgmtData;
    pinPage(&rManager->bufferPool, &rManager->pageHandle, id.page);
    rManager->freePage = id.page;
    char *info = rManager->pageHandle.data;
    int recordSize = getRecordSize(rel->schema);
    info = info + (id.slot * recordSize);
    *info = '-';
    markDirty(&rManager->bufferPool, &rManager->pageHandle);
    unpinPage(&rManager->bufferPool, &rManager->pageHandle);
    return RC_OK;
}

extern RC updateRecord (RM_TableData *rel, Record *record) {
    RecordManager *rManager = rel->mgmtData;
    pinPage(&rManager->bufferPool, &rManager->pageHandle, record->id.page);
    char *info;
    int recordSize = getRecordSize(rel->schema);
    RID id = record->id;
    info = rManager->pageHandle.data;
    info = info + (id.slot * recordSize);
    *info = '+';
    memcpy(++info, record->data + 1, recordSize - 1 );
    markDirty(&rManager->bufferPool, &rManager->pageHandle);
    unpinPage(&rManager->bufferPool, &rManager->pageHandle);
    return RC_OK;    
}

extern RC getRecord (RM_TableData *rel, RID id, Record *record) {
    RecordManager *rManager = rel->mgmtData;
    pinPage(&rManager->bufferPool, &rManager->pageHandle, id.page);
    int recordSize = getRecordSize(rel->schema);
    char *dataPointer = rManager->pageHandle.data;
    dataPointer = dataPointer + (id.slot * recordSize);
    if(*dataPointer != '+') {
        return RC_RM_NO_TUPLE_WITH_GIVEN_RID;
    }
    else {
        record->id = id;
        char *info = record->data;
        memcpy(++info, dataPointer + 1, recordSize - 1);
    }
    unpinPage(&rManager->bufferPool, &rManager->pageHandle);
    return RC_OK;
}

extern RC startScan (RM_TableData *rel, RM_ScanHandle *scan, Expr *cond) {
    if (cond == NULL)
        return RC_SCAN_CONDITION_NOT_FOUND;
    openTable(rel, "ScanTable");
    RecordManager *scanManager;
    RecordManager *tableManager;
    scanManager = (RecordManager*) malloc(sizeof(RecordManager));
    scan->mgmtData = scanManager;
    scanManager->recordID.page = 1;
    scanManager->recordID.slot = 0;
    scanManager->countScan = 0;
    scanManager->condition = cond;
    tableManager = rel->mgmtData;
    tableManager->countTuples = ATTRIBUTE_SIZE;
    scan->rel= rel;
    return RC_OK;
}

extern RC next(RM_ScanHandle *scan, Record *record) {
    RecordManager *scanManager = (*(scan)).mgmtData;
    RecordManager *tableManager = (*((*scan).rel)).mgmtData;
    Schema *schema = (*((*scan).rel)).schema;
    if ((*(scanManager)).condition == NULL)
        return RC_SCAN_CONDITION_NOT_FOUND;

    Value *result = (Value *) malloc(sizeof(Value));
    char *info;
    int recordSize = getRecordSize(schema);
    int totalSpace = PAGE_SIZE / recordSize;
    int countTuples = (*(tableManager)).countTuples;

    for (int countScan = (*(scanManager)).countScan; countScan <= countTuples; countScan++) {
        if (countScan <= 0) {
            (*(scanManager)).recordID.page = 1;
            (*(scanManager)).recordID.slot = 0;
        } else {
            (*(scanManager)).recordID.slot++;
            if ((*(scanManager)).recordID.slot >= totalSpace) {
                (*(scanManager)).recordID.slot = 0;
                (*(scanManager)).recordID.page++;
            }
        }

        pinPage(&((*(tableManager)).bufferPool), &((*(scanManager)).pageHandle), (*(scanManager)).recordID.page);
        info = (*(scanManager)).pageHandle.data;
        info = info + ((*(scanManager)).recordID.slot * recordSize);
        (*(record)).id.page = (*(scanManager)).recordID.page;
        (*(record)).id.slot = (*(scanManager)).recordID.slot;
        char *dataPointer = (*(record)).data;
        *dataPointer = '-';

        memcpy(++dataPointer, info + 1, recordSize - 1);
        (*(scanManager)).countScan++;
        evalExpr(record, schema, (*(scanManager)).condition, &result);

        if ((*(result)).v.boolV == TRUE) {
            unpinPage(&((*(tableManager)).bufferPool), &((*(scanManager)).pageHandle));
            return RC_OK;
        }
    }

    unpinPage(&((*(tableManager)).bufferPool), &((*(scanManager)).pageHandle));
    (*(scanManager)).recordID.page = 1;
    (*(scanManager)).recordID.slot = 0;
    (*(scanManager)).countScan = 0;

    return RC_RM_NO_MORE_TUPLES;
}


extern RC closeScan(RM_ScanHandle *scan) {
    if (!scan || !(*scan).mgmtData) return RC_OK;

    RecordManager *scanManager = (*scan).mgmtData;
    if (scanManager->countScan > 0) {
        unpinPage(&rManager->bufferPool, &scanManager->pageHandle);
        scanManager->countScan = 0;
        scanManager->recordID.page = 1;
        scanManager->recordID.slot = 0;
    }

    free((*scan).mgmtData);
    (*scan).mgmtData = NULL;

    return RC_OK;
}


extern int getRecordSize(Schema *schema) {
    int size = 0, i = 0;
    
    // Iterate over each attribute in the schema
    do {
        // Add the size of each attribute based on its data type
        if (schema->dataTypes[i] == DT_STRING) {
            size += schema->typeLength[i]; // Add the length of the string
        } else if (schema->dataTypes[i] == DT_INT) {
            size += sizeof(int); // Add the size of an integer
        } else if (schema->dataTypes[i] == DT_FLOAT) {
            size += sizeof(float); // Add the size of a float
        } else if (schema->dataTypes[i] == DT_BOOL) {
            size += sizeof(bool); // Add the size of a boolean
        }
        i++; // Move to the next attribute
    } while (i < schema->numAttr); // Continue until all attributes are processed
    
    return size + 1; // Add 1 for additional metadata
}


Schema *createSchema(int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys) {
    Schema *schema = (Schema *) malloc(sizeof(Schema));
    if (schema != NULL) {
        schema->numAttr = numAttr;
        schema->keySize = keySize;
        schema->keyAttrs = keys;
        schema->attrNames = attrNames;
        schema->typeLength = typeLength;
        schema->dataTypes = dataTypes;
    }
    return schema;
}

extern RC attrOffset(Schema *schema, int attrNum, int *result) {
    int i = 0;
    *result = 1; // Initialize the result with 1 to account for initial offset
    
    // Loop through attributes up to attrNum and calculate the offset
    while (i < attrNum) {
        // Update the result based on the data type of each attribute
        if (schema->dataTypes[i] == DT_STRING) {
            *result = *result + schema->typeLength[i];
        } else if (schema->dataTypes[i] == DT_INT) {
            *result = *result + sizeof(int);
        } else if (schema->dataTypes[i] == DT_FLOAT) {
            *result = *result + sizeof(float);
        } else if (schema->dataTypes[i] == DT_BOOL) {
            *result = *result + sizeof(bool);
        }
        i++; // Increment the index
    }
    
    return RC_OK; // Return success
}


extern RC freeSchema (Schema *schema) {
    free(schema);
    return RC_OK;
}

extern RC createRecord (Record **record, Schema *schema) {
    // Allocate memory for the new record
    Record *newRecord = malloc(sizeof(Record));
    if (newRecord == NULL) {
        return RC_RM_NO_MORE_TUPLES; // Error handling for memory allocation failure
    }
    
    // Get the size of the record based on the schema
    int recordSize = getRecordSize(schema);    
    
    // Allocate memory for the record data
    newRecord->data = malloc(recordSize);
    if (newRecord->data == NULL) {
        free(newRecord); // Free previously allocated memory
        return RC_RM_NO_MORE_TUPLES; // Error handling for memory allocation failure
    }
    
    // Initialize the record ID
    newRecord->id.page = newRecord->id.slot = -1;
    
    // Set default data for the record (here set as '-')
    memset(newRecord->data, '-', recordSize);
    
    // Set the record pointer
    *record = newRecord;
    
    return RC_OK;
}


extern RC freeRecord (Record *record) {
    free(record);
    return RC_OK;
}

extern RC getAttr(Record *record, Schema *schema, int attrNum, Value **value) {
    int offset = 0;
    attrOffset(schema, attrNum, &offset);
    Value *attribute = (Value*) malloc(sizeof(Value));
    char *dataPointer = record->data;
    dataPointer = dataPointer + offset;
    // If the attribute data type is not initialized, set it to a default value
    if (attrNum == 1) {
    schema->dataTypes[attrNum] = 1; // Set it to a default value of 1
    } else {
    // Otherwise, keep the existing data type
    schema->dataTypes[attrNum] = schema->dataTypes[attrNum];
    }

    // Check the data type of the attribute
    if (schema->dataTypes[attrNum] == DT_STRING) {
        int length = schema->typeLength[attrNum];
        attribute->v.stringV = (char *) malloc(length + 1);
        strncpy(attribute->v.stringV, dataPointer, length);
        attribute->v.stringV[length] = '\0';
        attribute->dt = DT_STRING;
    } else if (schema->dataTypes[attrNum] == DT_INT) {
        int intValue = 0;
        memcpy(&intValue, dataPointer, sizeof(int));
        attribute->v.intV = intValue;
        attribute->dt = DT_INT;
    } else if (schema->dataTypes[attrNum] == DT_FLOAT) {
        float floatValue;
        memcpy(&floatValue, dataPointer, sizeof(float));
        attribute->v.floatV = floatValue;
        attribute->dt = DT_FLOAT;
    } else if (schema->dataTypes[attrNum] == DT_BOOL) {
        bool boolValue;
        memcpy(&boolValue, dataPointer, sizeof(bool));
        attribute->v.boolV = boolValue;
        attribute->dt = DT_BOOL;
    } else {
        printf("Serializer dtattype is not defiled! \n");
    }

    // Assign the attribute to the output parameter
    *value = attribute;

    return RC_OK;
}


// Set String Attribute
extern RC setStringAttr(char *dataPointer, const char *value, int length) {
    strncpy(dataPointer, value, length);
    return RC_OK;
}

// Set Integer Attribute
extern RC setIntAttr(char *dataPointer, int value) {
    *(int *)dataPointer = value;
    return RC_OK;
}

// Set Float Attribute
extern RC setFloatAttr(char *dataPointer, float value) {
    *(float *)dataPointer = value;
    return RC_OK;
}

// Set Boolean Attribute
extern RC setBoolAttr(char *dataPointer, bool value) {
    *(bool *)dataPointer = value;
    return RC_OK;
}

// Revised setAttr function
extern RC setAttr(Record *record, Schema *schema, int attrNum, Value *value) {
    // Calculate the offset for the attribute within the record
    int offset = 0;
    attrOffset(schema, attrNum, &offset);
    
    // Get a pointer to the data location where the attribute will be set
    char *dataPointer = record->data;
    dataPointer = dataPointer + offset;

    // Check the data type of the attribute and set it accordingly
    if (schema->dataTypes[attrNum] == DT_STRING) {
        // Set string attribute
        setStringAttr(dataPointer, value->v.stringV, schema->typeLength[attrNum]);
    } else if (schema->dataTypes[attrNum] == DT_INT) {
        // Set integer attribute
        setIntAttr(dataPointer, value->v.intV);
    } else if (schema->dataTypes[attrNum] == DT_FLOAT) {
        // Set float attribute
        setFloatAttr(dataPointer, value->v.floatV);
    } else if (schema->dataTypes[attrNum] == DT_BOOL) {
        // Set boolean attribute
        setBoolAttr(dataPointer, value->v.boolV);
    } else {
        // Unsupported data type
        printf("Serializer not defined for the given datatype.\n");
    }

    return RC_OK;
}

