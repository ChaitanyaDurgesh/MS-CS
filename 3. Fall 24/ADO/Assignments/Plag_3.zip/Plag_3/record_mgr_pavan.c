#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "record_mgr.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"
#define RC_MEMORY_ALLOCATION_FAILED 1
#define RC_PIN_PAGE_FAILED 1
#define RC_UNPIN_PAGE_FAILED 1
#define RC_NULL_POINTER 1
#define RC_INVALID_DATA_TYPE 1
#define RC_MEM_ALLOC_FAILED 1
#define RC_INVALID_DATA_POINTER 1

typedef struct RecordManager {
    RID recordID;
    BM_PageHandle pageHandle;
    BM_BufferPool bufferPool;
    Expr *condition;
    int countTuples;
    int countScan;
    int freePage;
} RecordManager;

const int MAX_NUMBER_OF_PAGES = 100;
const int ATTRIBUTE_SIZE = 15;

RecordManager *rManager;

extern RC initRecordManager (void *mgmtData) {
    initStorageManager();
    return RC_OK;
}

extern RC shutdownRecordManager () {
	free(rManager);
    rManager = NULL;
    return RC_OK;
}

// Function to write metadata and attribute information into a buffer
static void writeMetadataAndAttributes(char *pageHandle, Schema *schema) {
    
    int iterator;
    *(int*)pageHandle = 0;
    pageHandle = (char*)((int*)pageHandle + 1);
    *(int*)pageHandle = 1;
    pageHandle = (char*)((int*)pageHandle + 1);
    *(int*)pageHandle = schema->numAttr;
    pageHandle = (char*)((int*)pageHandle + 1);
    *(int*)pageHandle = schema->keySize;
    pageHandle = (char*)((int*)pageHandle + 1);

    // Write attribute information
    for (iterator = 0; iterator < schema->numAttr; iterator++) {
        strncpy(pageHandle, schema->attrNames[iterator], ATTRIBUTE_SIZE);
        pageHandle += ATTRIBUTE_SIZE;
        *(int*)pageHandle = (int)schema->dataTypes[iterator];
        pageHandle = (char*)((int*)pageHandle + 1);
        *(int*)pageHandle = (int)schema->typeLength[iterator];
        pageHandle = (char*)((int*)pageHandle + 1);
    }

}

// Function to create a page file and write the buffer into it
extern RC createTable(char *name, Schema *schema) {
    rManager = (RecordManager*) malloc(sizeof(RecordManager));
    initBufferPool(&(rManager->bufferPool), name, MAX_NUMBER_OF_PAGES, RS_LRU, NULL);

    char info[PAGE_SIZE];
    char *pageHandle = info;
    int returnResult;

    // Write metadata and attribute information into the buffer
    writeMetadataAndAttributes(pageHandle, schema);

    SM_FileHandle fileHandle;
    returnResult = createPageFile(name);
    if(returnResult != 0)
    {
        return returnResult;
    }

    returnResult = openPageFile(name, &fileHandle);
    if(returnResult != 0)
    {
        return returnResult;
    }
        
    returnResult = writeBlock(0, &fileHandle, info);
    if(returnResult != 0)
    {
        return returnResult;
    }

    returnResult = closePageFile(&fileHandle);
    if(returnResult != 0)
    {
        return returnResult;
    }

    return RC_OK;
}



// Function to read metadata from page and update rManager
void readMetadataAndUpdateRM(RM_TableData *rel, char *name) {
    rel->mgmtData = rManager;
    rel->name = name; // Update the name
    pinPage(&rManager->bufferPool, &rManager->pageHandle, 0);
    SM_PageHandle pageHandle = (char*) rManager->pageHandle.data;
    rManager->countTuples = *(int*)pageHandle;
    pageHandle = (char*)((int*)pageHandle + 1);
    rManager->freePage = *(int*)pageHandle;
    pageHandle = (char*)((int*)pageHandle + 1);

}

// Function to allocate and populate schema
void allocateAndPopulateSchema(RM_TableData *rel) {
    int countAtt, k;
    SM_PageHandle pageHandle = (char*) rManager->pageHandle.data;
    pageHandle += 2 * sizeof(int);

    countAtt = *(int*)pageHandle;
    pageHandle += sizeof(int);

    Schema *schemaVal;
    schemaVal = (Schema*) malloc(sizeof(Schema));
    schemaVal->numAttr = countAtt;
    schemaVal->attrNames = (char**) malloc(sizeof(char*) *countAtt);
    schemaVal->dataTypes = (DataType*) malloc(sizeof(DataType) *countAtt);
    schemaVal->typeLength = (int*) malloc(sizeof(int) *countAtt);

    k = 0;
    while (k < countAtt) {
        schemaVal->attrNames[k] = (char*) malloc(ATTRIBUTE_SIZE);
        k++;
    }

    k = 0;
    while (k < schemaVal->numAttr) {
        strncpy(schemaVal->attrNames[k], pageHandle, ATTRIBUTE_SIZE);
        pageHandle += ATTRIBUTE_SIZE;
        schemaVal->dataTypes[k] = *(int*) pageHandle;
        pageHandle += sizeof(int);
        schemaVal->typeLength[k] = *(int*)pageHandle;
        pageHandle += sizeof(int);
        k++;
    }

    rel->schema = schemaVal;
}

// Modified openTable function to call the above two functions
extern RC openTable(RM_TableData *rel, char *name) {
    // Read metadata and update rManager
    readMetadataAndUpdateRM(rel, name); // Pass 'name' parameter
    // Allocate and populate schema
    allocateAndPopulateSchema(rel);
    // Force page after populating schema
    forcePage(&(rManager->bufferPool), &(rManager->pageHandle));

    return RC_OK;
}

extern RC closeTable (RM_TableData *riit) {
    RecordManager *rManager = riit->mgmtData;
    shutdownBufferPool(&rManager->bufferPool);
    return RC_OK;
}

extern RC deleteTable (char *xyz) {
    destroyPageFile(xyz);
    return RC_OK;
}

int findFreeSlot(char *data, int recordSize) {
    int totalSpace = PAGE_SIZE / recordSize;
    int i = 0;
    // Search for a free slot using a do-while loop
    do {
        // Check if the slot is free
        if (data[i * recordSize] != '+') {
            return i;
        }
        // Move to the next slot
        i++;
    } while (i < totalSpace);
    // No free slot found
    return -1;
}


extern int getNumTuples (RM_TableData *rel) {
    RecordManager *rManager = rel->mgmtData;
    return rManager->countTuples;
}

extern RC insertRecord(RM_TableData *rel, Record *record) {
    // Check for NULL pointers
    if (rel == NULL || record == NULL || rel->mgmtData == NULL) {
        return RC_NULL_POINTER;
    }

    RecordManager *rManager = rel->mgmtData;
    RID *recordID = &(record->id);
    int recordSize = getRecordSize(rel->schema);
    char *info;

    // Initialize recordID page
    recordID->page = rManager->freePage;

    // Iterate only once
    for (int i = 0; i < 1; i++) {
        // Pin the page
        if (pinPage(&(rManager->bufferPool), &(rManager->pageHandle), recordID->page) != RC_OK) {
            return RC_PIN_PAGE_FAILED;
        }
        
        info = rManager->pageHandle.data;
        char *ptrToSlots;

        // Find a free slot
        recordID->slot = findFreeSlot(info, recordSize);

        // Search for a free slot on subsequent pages if not found on the current page
        for (; recordID->slot == -1;) {
            // Unpin the page
            if (unpinPage(&(rManager->bufferPool), &(rManager->pageHandle)) != RC_OK) {
                return RC_UNPIN_PAGE_FAILED;
            }
            
            // Move to the next page
            recordID->page++;

            // Pin the next page
            if (pinPage(&(rManager->bufferPool), &(rManager->pageHandle), recordID->page) != RC_OK) {
                return RC_PIN_PAGE_FAILED;
            }
            
            info = rManager->pageHandle.data;

            recordID->slot = findFreeSlot(info, recordSize);
        }

        int recordSizeNew = recordSize;

        ptrToSlots = info;

        markDirty(&(rManager->bufferPool), &(rManager->pageHandle));

        ptrToSlots += (recordID->slot * recordSizeNew);

        char ch = '+';

        *ptrToSlots = ch;

        // Copy record data into the slot
        memcpy(ptrToSlots + 1, record->data + 1, recordSize - 1);

        // Unpin the page
        if (unpinPage(&(rManager->bufferPool), &(rManager->pageHandle)) != RC_OK) {
            return RC_UNPIN_PAGE_FAILED;
        }

        // Increment the count of tuples
        rManager->countTuples++;

        // Pin the first page
        if (pinPage(&(rManager->bufferPool), &(rManager->pageHandle), 0) != RC_OK) {
            return RC_PIN_PAGE_FAILED;
        }
    }

    return RC_OK;
}



// Function to mark a record as deleted
void markRecordAsDeleted(char *info) {
    *info = '-';
}

// Function to finalize the deletion process
void finalizeDeletion(RecordManager *rManager) {
    // Mark the page as dirty
    markDirty(&(rManager->bufferPool), &(rManager->pageHandle));

    // Unpin the page
    unpinPage(&(rManager->bufferPool), &(rManager->pageHandle));
}

// Main deleteRecord function
extern RC deleteRecord(RM_TableData *rel, RID id) {
    RecordManager *rManager = rel->mgmtData;

    // Pin the page
    pinPage(&(rManager->bufferPool), &(rManager->pageHandle), id.page);

    // Update the free page
    rManager->freePage = id.page;

    // Access the record data
    char *info = rManager->pageHandle.data;
    int recordSize = getRecordSize(rel->schema);
    info += (id.slot * recordSize);

    // Mark the record as deleted
    markRecordAsDeleted(info);

    // Finalize the deletion process
    finalizeDeletion(rManager);

    return RC_OK;
}

extern RC updateRecord(RM_TableData *rel, Record *record) {
    RecordManager *rManager = rel->mgmtData;
    pinPage(&rManager->bufferPool, &rManager->pageHandle, record->id.page);
    int recordSize = getRecordSize(rel->schema);
    char *info;
    RID id = record->id;
    info = rManager->pageHandle.data;
    info += (id.slot * recordSize);

    // Mark the record as valid
    *info = '+';

    // Copy the updated data into the record
    memcpy(++info, record->data + 1, recordSize - 1);

    // Mark the page as dirty
    markDirty(&rManager->bufferPool, &rManager->pageHandle);

    // Unpin the page
    unpinPage(&rManager->bufferPool, &rManager->pageHandle);

    return RC_OK;    
}



// Function to check if a record exists with the given RID
bool recordExists(RM_TableData *rel, RID id) {
    // Access the buffer pool and pin the page containing the record
    RecordManager *rManager = rel->mgmtData;
    if (pinPage(&rManager->bufferPool, &rManager->pageHandle, id.page) != RC_OK) {
        // Return false if pinning the page fails
        return false;
    }
    // Calculate the starting position of the record within the page
    int recordSize = getRecordSize(rel->schema);
    char *dataPointer = rManager->pageHandle.data + (id.slot * recordSize);
    // Check if the record exists based on the record marker
    bool exists = (*dataPointer == '+');
    // Unpin the page after accessing the record
    if (unpinPage(&rManager->bufferPool, &rManager->pageHandle) != RC_OK) {
        // Handle error if unpinning the page fails
        // This shouldn't affect the existence check result, so continue returning the existence status
    }
    return exists;
}


// Function to retrieve the record with the given RID
extern RC getRecord(RM_TableData *rel, RID id, Record *record) {
    if (!recordExists(rel, id)) {
        return RC_RM_NO_TUPLE_WITH_GIVEN_RID;
    }

    RecordManager *rManager = rel->mgmtData;
    pinPage(&rManager->bufferPool, &rManager->pageHandle, id.page);
    int recordSize = getRecordSize(rel->schema);
    char *dataPointer = rManager->pageHandle.data;
    dataPointer += (id.slot * recordSize);

    record->id = id;
    char *info = record->data;
    memcpy(++info, dataPointer + 1, recordSize - 1);

    unpinPage(&rManager->bufferPool, &rManager->pageHandle);
    return RC_OK;
}




extern RC startScan(RM_TableData *rel, RM_ScanHandle *scan, Expr *cond) {
    if (cond == NULL) {
        // Check if condition is provided
        return RC_SCAN_CONDITION_NOT_FOUND;
    }
    // Open the table
    openTable(rel, "ScanTable");
    // Allocate memory for scan manager and assign to scan handle
    RecordManager *scanManager = (RecordManager *)malloc(sizeof(RecordManager));
    if (scanManager == NULL) {
        // Handle memory allocation error
        return RC_MEMORY_ALLOCATION_FAILED;
    }
    scan->mgmtData = scanManager;
    // Initialize scan manager
    int g = 1;
    int h = 0;
    scanManager->recordID.page = g;
    scanManager->recordID.slot = h;
    scanManager->countScan = h;
    scanManager->condition = cond;
    RecordManager *tableManager = rel->mgmtData;
    // Set countTuples to ATTRIBUTE_SIZE if it's not already set
    if (tableManager->countTuples == 0) {
        tableManager->countTuples = ATTRIBUTE_SIZE;
    }
    // Assign table data to scan handle
    scan->rel = rel;
    return RC_OK;
}


#define RC_MEMORY_ALLOCATION_FAILED 1
extern RC next(RM_ScanHandle *scan, Record *record) {
    RecordManager *scanManager = (*(scan)).mgmtData;
    RecordManager *tableManager = (*((*scan).rel)).mgmtData;
    Schema *schema = (*((*scan).rel)).schema;
    if ((*(scanManager)).condition == NULL)
        return RC_SCAN_CONDITION_NOT_FOUND;

    Value *result = (Value *) malloc(sizeof(Value));
    if (result == NULL) 
    // Handle memory allocation error
    return RC_MEMORY_ALLOCATION_FAILED;

    char *info;
    int recordSize = getRecordSize(schema);
    int totalSpace = PAGE_SIZE / recordSize;
    int countTuples = (*(tableManager)).countTuples;

    for (int countScan = (*(scanManager)).countScan; countScan <= countTuples; countScan++) {
        if (countScan <= 0) {
            (*(scanManager)).recordID.page = 1;
            (*(scanManager)).recordID.slot = 0;
        } else {
            (*(scanManager)).recordID.slot++;
            if ((*(scanManager)).recordID.slot >= totalSpace) {
                (*(scanManager)).recordID.slot = 0;
                (*(scanManager)).recordID.page++;
            }
        }

        pinPage(&((*(tableManager)).bufferPool), &((*(scanManager)).pageHandle), (*(scanManager)).recordID.page);
        info = (*(scanManager)).pageHandle.data;
        info = info + ((*(scanManager)).recordID.slot * recordSize);
        (*(record)).id.page = (*(scanManager)).recordID.page;
        (*(record)).id.slot = (*(scanManager)).recordID.slot;
        char *dataPointer = (*(record)).data;
        *dataPointer = '-';

        memcpy(++dataPointer, info + 1, recordSize - 1);
        (*(scanManager)).countScan++;
        evalExpr(record, schema, (*(scanManager)).condition, &result);

        if ((*(result)).v.boolV == TRUE) {
            unpinPage(&((*(tableManager)).bufferPool), &((*(scanManager)).pageHandle));
            return RC_OK;
        }
    }

    unpinPage(&((*(tableManager)).bufferPool), &((*(scanManager)).pageHandle));
    (*(scanManager)).recordID.page = 1;
    (*(scanManager)).recordID.slot = 0;
    (*(scanManager)).countScan = 0;

    return RC_RM_NO_MORE_TUPLES;
}


extern RC closeScan(RM_ScanHandle *scan) {
    if (scan == NULL) {
        // Handle NULL pointer error
        return RC_NULL_POINTER;
    }
    // Check if the scan handle is already closed
    if (scan->mgmtData == NULL) {
        // Return OK since there's nothing to close
        return RC_OK;
    }
    RecordManager *scanManager = scan->mgmtData;
    // Check if there are ongoing scans
    if (scanManager->countScan > 0) {
        // Unpin the page and reset counters
        if (unpinPage(&(scanManager->bufferPool), &(scanManager->pageHandle)) != RC_OK) {
            // Handle unpinning error
            return RC_UNPIN_PAGE_FAILED;
        }
        scanManager->countScan = 0;
        scanManager->recordID.page = 1;
        scanManager->recordID.slot = 0;
    }
    // Free memory allocated for scan manager
    free(scan->mgmtData);
    scan->mgmtData = NULL;
    return RC_OK;
}

extern int getRecordSize(Schema *schema) {
    int size = 0, i = 0;
    
    do {
        // Add the size of each attribute based on its data type
        if (schema->dataTypes[i] == DT_STRING) {
            size += schema->typeLength[i]; // Add the length of the string
        } else if (schema->dataTypes[i] == DT_INT) {
            size += sizeof(int); // Add the size of an integer
        } else if (schema->dataTypes[i] == DT_FLOAT) {
            size += sizeof(float); // Add the size of a float
        } else if (schema->dataTypes[i] == DT_BOOL) {
            size += sizeof(bool); // Add the size of a boolean
        }
        i++; // Move to the next attribute
    } while (i < schema->numAttr); // Continue until all attributes are processed
    
    return size + 1; // Add 1 for additional metadata
}


Schema *createSchema(int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys) {
    // Allocate memory for the Schema struct
    Schema *schema = (Schema *)malloc(sizeof(Schema));
    if (schema == NULL) {
        // Handle memory allocation error
        return NULL;
    }
    
    // Allocate memory for attribute names array
    schema->attrNames = (char **)malloc(numAttr * sizeof(char *));
    if (schema->attrNames == NULL) {
        // Handle memory allocation error
        free(schema);
        return NULL;
    }
    
    // Copy attribute names
    for (int i = 0; i < numAttr; i++) {
        size_t attrNameLen = strlen(attrNames[i]) + 1; // Including null terminator
        schema->attrNames[i] = (char *)malloc(attrNameLen * sizeof(char));
        if (schema->attrNames[i] == NULL) {
            // Handle memory allocation error
            // Free previously allocated memory
            for (int j = 0; j < i; j++) {
                free(schema->attrNames[j]);
            }
            free(schema->attrNames);
            free(schema);
            return NULL;
        }
        strcpy(schema->attrNames[i], attrNames[i]);
    }
    
    // Copy other attributes
    schema->numAttr = numAttr;
    schema->keySize = keySize;
    schema->keyAttrs = keys;
    schema->typeLength = typeLength;
    schema->dataTypes = (DataType *)malloc(numAttr * sizeof(DataType));
    if (schema->dataTypes == NULL) {
        // Handle memory allocation error
        // Free previously allocated memory
        for (int i = 0; i < numAttr; i++) {
            free(schema->attrNames[i]);
        }
        free(schema->attrNames);
        free(schema);
        return NULL;
    }
    memcpy(schema->dataTypes, dataTypes, numAttr * sizeof(DataType));
    
    return schema;
}


extern RC attrOffset(Schema *schema, int attrNum, int *result) {
    int i = 0;
    *result = 1; // Initialize the result with 1 to account for initial offset
    
    // Loop through attributes up to attrNum and calculate the offset
    while (i < attrNum) {
        // Update the result based on the data type of each attribute
        if (schema->dataTypes[i] == DT_STRING) {
            *result = *result + schema->typeLength[i];
        } else if (schema->dataTypes[i] == DT_INT) {
            *result = *result + sizeof(int);
        } else if (schema->dataTypes[i] == DT_FLOAT) {
            *result = *result + sizeof(float);
        } else if (schema->dataTypes[i] == DT_BOOL) {
            *result = *result + sizeof(bool);
        }
        i++; // Increment the index
    }
    
    return RC_OK; // Return success
}

#define RC_SCHEMA_POINTER_NULL 1

extern RC freeSchema(Schema *rec_schema) {
    if (rec_schema == NULL) {
        return RC_SCHEMA_POINTER_NULL;
    }
    for (int i = 0; i < rec_schema->numAttr; i++) {
        free(rec_schema->attrNames[i]);
    }
    free(rec_schema->attrNames);
    free(rec_schema->dataTypes);
    free(rec_schema);
    return RC_OK;
}



extern RC createRecord (Record **record, Schema *schema) {
    // Allocate memory for the new record
    Record *newRecord = malloc(sizeof(Record));
    if (newRecord == NULL) {
        return RC_RM_NO_MORE_TUPLES; // Error handling for memory allocation failure
    }
    // Get the size of the record based on the schema
    int recordSize = getRecordSize(schema);    
    // Allocate memory for the record data
    newRecord->data = malloc(recordSize);
    if (newRecord->data == NULL) {
        free(newRecord); // Free previously allocated memory
        return RC_RM_NO_MORE_TUPLES; // Error handling for memory allocation failure
    }
    // Initialize the record ID
    newRecord->id.page = newRecord->id.slot = -1;
    // Set default data for the record (here set as '-')
    memset(newRecord->data, '-', recordSize);
    // Set the record pointer
    *record = newRecord;
    return RC_OK;
}

extern RC freeRecord(Record *rec) {
    if (rec == NULL) {
        // Handle NULL pointer error
        return RC_NULL_POINTER;
    }

    // Check if the record data pointer is NULL
    if (rec->data == NULL) {
        // Free the record structure and return OK
        free(rec);
        return RC_OK;
    } else {
        // Free the record data and then the record structure
        free(rec->data);
        free(rec);
        return RC_OK;
    }
}


extern RC getAttr(Record *record, Schema *schema, int attrNum, Value **value) {
    // Check for NULL pointers
    if (record == NULL || schema == NULL || value == NULL) {
        return RC_NULL_POINTER;
    }

    // Calculate the offset of the attribute within the record
    int offset = 0;
    attrOffset(schema, attrNum, &offset);

    // Allocate memory for the Value structure
    Value *attribute = (Value*) malloc(sizeof(Value));
    if (attribute == NULL) {
        return RC_MEM_ALLOC_FAILED;
    }

    // Get a pointer to the attribute's data within the record
    char *dataPointer = record->data + offset;

    // If the attribute data type is not initialized, set it to a default value
    if (attrNum == 1) {
        schema->dataTypes[attrNum] = 1; // Set it to a default value of 1
    } else {
        // Otherwise, keep the existing data type
        schema->dataTypes[attrNum] = schema->dataTypes[attrNum];
    }

    // Check the data type of the attribute
    if (schema->dataTypes[attrNum] == DT_STRING) {
        int length = schema->typeLength[attrNum];
        attribute->v.stringV = (char *) malloc(length + 1);
        if (attribute->v.stringV == NULL) {
            free(attribute);
            return RC_MEM_ALLOC_FAILED;
        }
        if (dataPointer == NULL) {
            free(attribute->v.stringV);
            free(attribute);
            return RC_INVALID_DATA_POINTER;
        }
        strncpy(attribute->v.stringV, dataPointer, length);
        attribute->v.stringV[length] = '\0';
        attribute->dt = DT_STRING;
    } else {
        if (schema->dataTypes[attrNum] == DT_INT) {
            int intValue = 0;
            memcpy(&intValue, dataPointer, sizeof(int));
            attribute->v.intV = intValue;
            attribute->dt = DT_INT;
        } else {
            if (schema->dataTypes[attrNum] == DT_FLOAT) {
                float floatValue;
                memcpy(&floatValue, dataPointer, sizeof(float));
                attribute->v.floatV = floatValue;
                attribute->dt = DT_FLOAT;
            } else {
                if (schema->dataTypes[attrNum] == DT_BOOL) {
                    bool boolValue;
                    memcpy(&boolValue, dataPointer, sizeof(bool));
                    attribute->v.boolV = boolValue;
                    attribute->dt = DT_BOOL;
                } else {
                    printf("Serializer data type is not defined! \n");
                    free(attribute);
                    return RC_INVALID_DATA_TYPE;
                }
            }
        }
    }

    // Assign the attribute to the output parameter
    *value = attribute;

    return RC_OK;
}


// Set String Attribute
extern RC setStringAttr(char *dataPointer, const char *value, int length) {
    strncpy(dataPointer, value, length);
    return RC_OK;
}

// Set Integer Attribute
extern RC setIntAttr(char *dataPointer, int value) {
    *(int *)dataPointer = value;
    return RC_OK;
}

// Set Float Attribute
extern RC setFloatAttr(char *dataPointer, float value) {
    *(float *)dataPointer = value;
    return RC_OK;
}


extern RC setBoolAttr(char *dataPointer, bool value) {
    *(bool *)dataPointer = value;
    return RC_OK;
}

#define RC_INVALID_ATTR_NUM 1
#define RC_UNSUPPORTED_DATA_TYPE 1
#define RC_INVALID_DATATYPE_FOR_ATTR 1

extern RC setAttr(Record *record, Schema *schema, int attrNum, Value *value) {
    // Check for NULL pointers
    if (record == NULL || schema == NULL || value == NULL) {
        return RC_NULL_POINTER;
    }

    // Calculate the offset of the attribute within the record
    int offset = 0;
    attrOffset(schema, attrNum, &offset);

    // Check if the attribute number is valid
    if (attrNum < 0 || attrNum >= schema->numAttr) {
        return RC_INVALID_ATTR_NUM;
    }

    // Check if the attribute data type is supported
    if (schema->dataTypes[attrNum] != DT_STRING &&
        schema->dataTypes[attrNum] != DT_INT &&
        schema->dataTypes[attrNum] != DT_FLOAT &&
        schema->dataTypes[attrNum] != DT_BOOL) {
        printf("Serializer not defined for the given datatype.\n");
        return RC_UNSUPPORTED_DATA_TYPE;
    }

    // Get a pointer to the attribute's data within the record
    char *dataPointer = record->data + offset;

    // Set the attribute based on its data type
    if (schema->dataTypes[attrNum] == DT_STRING) {
        // Set string attribute
        if (value->dt != DT_STRING) {
            return RC_INVALID_DATATYPE_FOR_ATTR;
        }
        setStringAttr(dataPointer, value->v.stringV, schema->typeLength[attrNum]);
    } else if (schema->dataTypes[attrNum] == DT_INT) {
        // Set integer attribute
        if (value->dt != DT_INT) {
            return RC_INVALID_DATATYPE_FOR_ATTR;
        }
        setIntAttr(dataPointer, value->v.intV);
    } else if (schema->dataTypes[attrNum] == DT_FLOAT) {
        // Set float attribute
        if (value->dt != DT_FLOAT) {
            return RC_INVALID_DATATYPE_FOR_ATTR;
        }
        setFloatAttr(dataPointer, value->v.floatV);
    } else if (schema->dataTypes[attrNum] == DT_BOOL) {
        // Set boolean attribute
        if (value->dt != DT_BOOL) {
            return RC_INVALID_DATATYPE_FOR_ATTR;
        }
        setBoolAttr(dataPointer, value->v.boolV);
    }

    return RC_OK;
}


