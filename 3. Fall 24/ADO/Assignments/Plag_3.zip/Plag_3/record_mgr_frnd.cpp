#include <iostream>
#include <fstream>
#include <cmath>
#include <cstring>
#include <unistd.h>
#include <memory>
#include <filesystem>

using namespace std;


extern "C"{
    #include "buffer_mgr.h"
    #include "storage_mgr.h"
    #include "record_mgr.h"
    #include "tables.h"
    #include "rm_serializer.h"
    #include "rm_deserializer.h"


    typedef struct RecordInfo {
        Expr *cond;
        int currentSlot;
        int currentPage;
        int numPages;
        int numSlots;

    }RecordInfo;

    RC initRecordManager(void *mgmtData) {
        cout << "=> Initialising Record Manager" << endl;
        return RC_OK;
    }

    RC shutdownRecordManager() {
        cout << "=> Shutting down Record Manager" << endl;
        return RC_OK;
    }

    Schema *createSchema(int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys) {
        Schema *schema = new Schema;

        schema->numAttr = numAttr;
        schema->attrNames = attrNames;
        schema->dataTypes = dataTypes;
        schema->typeLength = typeLength;
        schema->keySize = keySize;
        schema->keyAttrs = keys;

        return schema;
    }

    RC freeSchema(Schema *schema) {
        delete schema;
        return RC_OK;
    }

    int getSchemaSize(Schema *schema) {
        int size = 0;

        size += sizeof(int);  // numAttr
        size += sizeof(int) * schema->numAttr;  // dataTypes
        size += sizeof(int) * schema->numAttr;  // typeLengths
        size += sizeof(int);  // keySize
        size += sizeof(int) * schema->keySize;  // keyAttrs

        for (int i = 0; i < schema->numAttr; i++) {
            size += strlen(schema->attrNames[i]);
        }

        return size;
    }
    int lenSlots(Schema *schema) {
        int lenSlots = 0;
        int square_brackets = 2;
        int integer_size = 5;
        int hyphen = 1;
        int space = 1;
        int bracket = 1;
        int colon =1;

        lenSlots += (square_brackets + integer_size  + integer_size + space + hyphen + bracket); 
        for (int i = 0; i < schema->numAttr; i++) {
            int tempSize;
            if (schema->dataTypes[i] == DT_STRING) {
                tempSize = schema->typeLength[i];
            } else if (schema->dataTypes[i] == DT_INT) {
                tempSize = 5;
            } else if (schema->dataTypes[i] == DT_FLOAT) {
                tempSize = 10;
            } else if (schema->dataTypes[i] == DT_BOOL) {
                tempSize = 5;
            }
            lenSlots += (tempSize + strlen(schema->attrNames[i]) + colon + bracket);  
        }
        return lenSlots;
    }
 

    RC createTable(char* name, Schema* schema) {
        // Check if table already exists
        if(filesystem::exists(name)) {
            return RC_TABLE_ALREADY_EXISTS;
        }

        int status;
        SM_FileHandle fh;

        if ((status = createPageFile(name)) != RC_OK)
            return status;

        int schemaSize = getSchemaSize(schema);
        int SlotLen = lenSlots(schema);
        int fileSize = static_cast<int>(ceil(static_cast<float>(schemaSize) / PAGE_SIZE));
        int maxSlots = static_cast<int>(floor(static_cast<float>(PAGE_SIZE) / static_cast<float>(SlotLen)));

        if ((status = openPageFile(name, &fh)) != RC_OK)
            return status;

        if ((status = ensureCapacity((fileSize + 1), &fh)) != RC_OK) {
            return status;
        }

        // First page with Table Data
        tableMgmtData *tInfo = new tableMgmtData();
        tInfo->lenTuples = 0;
        tInfo->schemaSize = schemaSize;
        tInfo->recordStart = fileSize + 1;
        tInfo->lenSlots = SlotLen;
        tInfo->recordEnd = fileSize + 1;
        tInfo->maxSlots = maxSlots;
        tInfo->tnodesStart = nullptr;

        char *info_str = serializeTableMgmtInfo(tInfo);
        if ((status = writeBlock(0, &fh, info_str)) != RC_OK)
            return status;

        char *schema_str = serializeSchema(schema);
        if ((status = writeBlock(1, &fh, schema_str)) != RC_OK)
            return status;

        if ((status = closePageFile(&fh)) != RC_OK)
            return status;

        return RC_OK;
    }

    RC openTable(RM_TableData *rel, char *name) {
        if (!filesystem::exists(name)) {
            return RC_TABLE_NOT_FOUND;
        }

        BM_BufferPool *buffer = new BM_BufferPool;
        BM_PageHandle *page = new BM_PageHandle;

        initBufferPool(buffer, name, 3, RS_FIFO, NULL);
        pinPage(buffer, page, 0);

        tableMgmtData *tInfo = deserializeTableMgmtInfo(page->data);

        if (tInfo->schemaSize < PAGE_SIZE) {
            pinPage(buffer, page, 1);
        }

        rel->schema = deserializeSchema(page->data);
        rel->name = name;

        tInfo->bm = buffer;
        rel->mgmtData = tInfo;

        delete page;

        return RC_OK;
    }

    RC closeTable(RM_TableData *rel) {

        shutdownBufferPool(static_cast<tableMgmtData *>(rel->mgmtData)->bm);
        delete static_cast<tableMgmtData *>(rel->mgmtData);

        delete rel->schema->dataTypes;
        delete rel->schema->attrNames;

        delete rel->schema->keyAttrs;
        delete rel->schema->typeLength;

        delete rel->schema;

        return RC_OK;
    }

    RC deleteTable(char *name) {
        if (!filesystem::exists(name)) {
            return RC_TABLE_NOT_FOUND;
        } else {
            filesystem::remove(name);
        }
        return RC_OK;
    }

    int getNumTuples(RM_TableData *rel) {
        return static_cast<tableMgmtData *>(rel->mgmtData)->lenTuples;
    }

    RC startScan(RM_TableData *rel, RM_ScanHandle *scan, Expr *cond) {

        scan->rel = rel;

        RecordInfo *rNode = new RecordInfo;
        rNode->currentPage = static_cast<tableMgmtData *>(rel->mgmtData)->recordStart;
        rNode->currentSlot = 0;
        rNode->cond = cond;
        rNode->numSlots = static_cast<tableMgmtData *>(rel->mgmtData)->maxSlots;
        rNode->numPages = static_cast<tableMgmtData *>(rel->mgmtData)->recordEnd;

        // store Record Info in mgmt
        scan->mgmtData = static_cast<void *>(rNode);

        return RC_OK;
    }

    RC next(RM_ScanHandle *scan, Record *record) {

        RecordInfo *rNode;
        Value *value;
        rNode = static_cast<RecordInfo *>(scan->mgmtData);
        RC operationStatus;

        record->id.slot = rNode->currentSlot;
        record->id.page = rNode->currentPage;

        // retrive the record
        operationStatus = getRecord(scan->rel, record->id, record);

        switch (operationStatus) {
            case RC_RM_NO_MORE_TUPLES:
                return RC_RM_NO_MORE_TUPLES;
            default:
                switch (record->id.tstone) {
                    case 1:
                        if (rNode->currentSlot == rNode->numSlots - 1) {
                            rNode->currentSlot = 0;
                            (rNode->currentPage)++;
                        } else {
                            (rNode->currentSlot)++;
                        }
                        scan->mgmtData = rNode;
                        return next(scan, record);
                    default:
                        evalExpr(record, scan->rel->schema, rNode->cond, &value);
                        if (rNode->currentSlot == rNode->numSlots - 1) {
                            rNode->currentSlot = 0;
                            (rNode->currentPage)++;
                        } else {
                            (rNode->currentSlot)++;
                        }
                        scan->mgmtData = rNode;

                        // Move to next record if it does not match the criteria
                        switch (value->v.boolV) {
                            case 1:
                                return RC_OK;
                            default:
                                return next(scan, record);
                        }
                }
        }
    }

    RC closeScan(RM_ScanHandle *scan) {
        scan->mgmtData = nullptr;
        scan->rel = nullptr;
        return RC_OK;
    }

    int getRecordSize(Schema *schema) {
        int size = 0, tempSize = 0;

        for (int i = 0; i < schema->numAttr; ++i) {
            if (schema->dataTypes[i] == DT_STRING) {
                tempSize = schema->typeLength[i];
            } else if (schema->dataTypes[i] == DT_INT) {
                tempSize = sizeof(int);
            } else if (schema->dataTypes[i] == DT_FLOAT) {
                tempSize = sizeof(float);
            } else if (schema->dataTypes[i] == DT_BOOL) {
                tempSize = sizeof(bool1);
            }
            size += tempSize;
        }
        return size;
    }
    RC createRecord(Record** record, Schema* schema) {
        *record = new Record;
        (*record)->data = new char[getRecordSize(schema)];
        return RC_OK;
    }

    RC freeRecord(Record* record) {
        delete record->data;
        delete record;
        return RC_OK;
    }
    RC tableInfoToFile(char* name, tableMgmtData* tInfo) {
        if (!filesystem::exists(name)) {
            return RC_TABLE_NOT_FOUND;
        }

        SM_FileHandle fh;
        int status;

        if ((status = openPageFile(name, &fh)) != RC_OK) {
            return status;
        }

        char* info_str = serializeTableMgmtInfo(tInfo);
        if ((status = writeBlock(0, &fh, info_str)) != RC_OK) {
            delete info_str;
            return status;
        }

        if ((status = closePageFile(&fh)) != RC_OK) {
            delete info_str;
            return status;
        }

        delete info_str;
        return RC_OK;
    }
    RC insertRecord(RM_TableData* rel, Record* record) {
        BM_PageHandle* page = new BM_PageHandle();
        tableMgmtData* tInfo = static_cast<tableMgmtData*>(rel->mgmtData);
        int pageNum, slot;

        if (tInfo->tnodesStart != nullptr) {
            pageNum = tInfo->tnodesStart->id.page;
            slot = tInfo->tnodesStart->id.slot;
            tInfo->tnodesStart = tInfo->tnodesStart->next;
        } else {
            pageNum = tInfo->recordEnd;
            slot = tInfo->lenTuples - ((pageNum - tInfo->recordStart) * tInfo->maxSlots);

            if (slot == tInfo->maxSlots) {
                slot = 0;
                pageNum++;
            }
            tInfo->recordEnd = pageNum;
        }

        record->id.page = pageNum;
        record->id.slot = slot;

        char* record_str = serializeRecord(record, rel->schema);

        pinPage(tInfo->bm, page, pageNum);
        memcpy(page->data + (slot * tInfo->lenSlots), record_str, strlen(record_str));
        delete record_str;

        markDirty(tInfo->bm, page);
        unpinPage(tInfo->bm, page);
        forcePage(tInfo->bm, page);

        record->id.tstone = false;
        (tInfo->lenTuples)++;
        tableInfoToFile(rel->name, tInfo);
        delete page;
        return RC_OK;
    }

    RC deleteRecord(RM_TableData *rel, RID id) {
        tableMgmtData *tInfo = reinterpret_cast<tableMgmtData *>(rel->mgmtData);
        tombstoneNode *tstone_iter = tInfo->tnodesStart;

        if (tInfo->lenTuples > 0) {
            // add deleted RID to the end of tombstone list
            if (tInfo->tnodesStart == nullptr) {
                tInfo->tnodesStart = new tombstoneNode();
                tInfo->tnodesStart->next = nullptr;
                tstone_iter = tInfo->tnodesStart;
            } else {
                while (tstone_iter->next != nullptr) {
                    tstone_iter = tstone_iter->next;
                }
                tstone_iter->next = new tombstoneNode();
                tstone_iter = tstone_iter->next;
                tstone_iter->next = nullptr;
            }

            tstone_iter->id.page = id.page;
            tstone_iter->id.slot = id.slot;
            tstone_iter->id.tstone = 1;
            (tInfo->lenTuples)--;
            (tInfo->numTnodes)++;
            tableInfoToFile(rel->name, tInfo);
        } else {
            return RC_WRITE_FAILED;
        }

        return RC_OK;
    }

    RC updateRecord(RM_TableData *rel, Record *record) {
        BM_PageHandle *page = static_cast<BM_PageHandle *>(malloc(sizeof(BM_PageHandle)));
        tableMgmtData *tInfo = static_cast<tableMgmtData *>(rel->mgmtData);
        int pageNum, slot;

        pageNum = record->id.page;
        slot = record->id.slot;

        char *record_str = serializeRecord(record, rel->schema);

        pinPage(tInfo->bm, page, pageNum);
        memcpy(page->data + (slot * tInfo->lenSlots), record_str, strlen(record_str));
        delete record_str;

        markDirty(tInfo->bm, page);
        unpinPage(tInfo->bm, page);
        forcePage(tInfo->bm, page);

        tableInfoToFile(rel->name, tInfo);

        return RC_OK;
    }

    RC getRecord(RM_TableData* rel, RID id, Record* record) {
        tableMgmtData* tInfo = static_cast<tableMgmtData*>(rel->mgmtData);
        BM_PageHandle* page = new BM_PageHandle();

        int pageNum, slot;
        pageNum = id.page;
        slot = id.slot;

        record->id.page = pageNum;
        record->id.slot = slot;
        record->id.tstone = 0;

        // Check if tombstone
        tombstoneNode* root = tInfo->tnodesStart;
        int tombStoneFlag = 0;
        int tombStoneCount = 0;

        int k = 0;
        for (k = 0; k < tInfo->numTnodes; ++k) {
            if (root->id.page == pageNum && root->id.slot == slot) {
                tombStoneFlag = 1;
                record->id.tstone = 1;
                break;
            }
            root = root->next;
            tombStoneCount++;
        }

        // If it is not tombstoned the retrive the record
        if (tombStoneFlag == 0) {
            int tupleNumber = (pageNum - tInfo->recordStart) * (tInfo->maxSlots) + slot + 1 - tombStoneCount;
            if (tupleNumber > tInfo->lenTuples) {
                delete page;
                return RC_RM_NO_MORE_TUPLES;
            }

            pinPage(tInfo->bm, page, pageNum);
            char* record_str = new char[sizeof(char) * tInfo->lenSlots];
            memcpy(record_str, page->data + ((slot)*tInfo->lenSlots), sizeof(char) * tInfo->lenSlots);
            unpinPage(tInfo->bm, page);

            Record* temp_record = deserializeRecord(record_str, rel);

            record->data = temp_record->data;
            delete temp_record;
        } else {
            // If Record is tombstoned accessing it, is not possible
            return RC_RECORD_TOMBSTONED;
        }

        delete page;
        return RC_OK;
    }

    RC getAttr(Record *record, Schema *schema, int attrNum, Value **value) {
        *value = new Value;
        int offset;
        char *atrributeData;

        attrOffset(schema, attrNum, &offset);
        atrributeData = (record->data + offset);
        (*value)->dt = schema->dataTypes[attrNum];

        if (schema->dataTypes[attrNum] == DT_INT) {
            memcpy(&((*value)->v.intV), atrributeData, sizeof(int));
        } else if (schema->dataTypes[attrNum] == DT_STRING) {
            int len = schema->typeLength[attrNum];
            char *stringValue;
            stringValue = new char[len + 1];
            strncpy(stringValue, atrributeData, len);
            stringValue[len] = '\0';
            (*value)->v.stringV = stringValue;
        } else if (schema->dataTypes[attrNum] == DT_FLOAT) {
            memcpy(&((*value)->v.floatV), atrributeData, sizeof(float));
        } else if (schema->dataTypes[attrNum] == DT_BOOL) {
            memcpy(&((*value)->v.boolV), atrributeData, sizeof(bool1));
        }

        return RC_OK;
    }

    RC setAttr(Record *record, Schema *schema, int attrNum, Value *value) {
        int offset;
        char *atrributeData;

        attrOffset(schema, attrNum, &offset);
        atrributeData = record->data + offset;

        if (schema->dataTypes[attrNum] == DT_INT) {
            memcpy(atrributeData, &(value->v.intV), sizeof(int));
        } else if (schema->dataTypes[attrNum] == DT_STRING) {
            char *stringValue;
            int len = schema->typeLength[attrNum];
            stringValue = new char[len];
            stringValue = value->v.stringV;
            memcpy(atrributeData, (stringValue), len);
        } else if (schema->dataTypes[attrNum] == DT_FLOAT) {
            memcpy(atrributeData, &((value->v.floatV)), sizeof(float));
        } else if (schema->dataTypes[attrNum] == DT_BOOL) {
            memcpy(atrributeData, &((value->v.boolV)), sizeof(bool1));
        }

        return RC_OK;
    }
}