#include <iostream>
#include <fstream>
#include <cmath>
#include <cstring>
#include <unistd.h>
#include <memory>
#include <filesystem>

#ifndef STATUS_CODES
#define STATUS_CODES
const int RC_OK = 0; // Example definition, replace with actual implementation
#endif

// Prefer using declarations over blanket 'using namespace std;'
using std::cin;
using std::cout;
using std::endl;
using std::fstream;
using std::unique_ptr;
using std::filesystem::path;

extern "C" {
    #include "buffer_mgr.h"
    #include "storage_mgr.h"
    #include "record_mgr.h"
    #include "tables.h"
    #include "rm_serializer.h"
    #include "rm_deserializer.h"
}

// Using a class to encapsulate RecordInfo functionality
class RecordInfo {
public:
    RecordInfo(Expr* condition, int slotsPerPage)
        : condition_(condition), currentSlot_(0), currentPage_(0),
          numPages_(0), numSlots_(slotsPerPage) {}

    // Accessors for the record information
    Expr* getCondition() const { return condition_; }
    int getCurrentSlot() const { return currentSlot_; }
    int getCurrentPage() const { return currentPage_; }
    int getNumPages() const { return numPages_; }
    int getNumSlots() const { return numSlots_; }

    // Modifiers for the record information
    void setCurrentSlot(int slot) { currentSlot_ = slot; }
    void setCurrentPage(int page) { currentPage_ = page; }
    void setNumPages(int numPages) { numPages_ = numPages; }
    void setNumSlots(int numSlots) { numSlots_ = numSlots; }

private:
    Expr* condition_;
    int currentSlot_;
    int currentPage_;
    int numPages_;
    int numSlots_;
};


void logInitializationMessage(const std::string& message) {
    std::cout << message << std::endl;
}

RC initRecordManager(void *mgmtData) {
    if (mgmtData == nullptr) {
        logInitializationMessage("=> Record Manager Initialization: No management data provided.");
    } else {
        logInitializationMessage("=> Initialising Record Manager with provided management data.");
    }
    
    return RC_OK;
}

void logSystemMessage(const std::string& message) {
    std::cout << "[Record Manager] " << message << std::endl;
}


RC shutdownRecordManager() {
    logSystemMessage("Shutdown initiated.");

    return RC_OK;
}

Schema *createSchema(int attributeCount, char **attributeNames, DataType *attributeTypes, int *attributeLengths, int primaryKeySize, int *primaryKeyAttributes) {
    // Safety check for input parameters
    if (attributeCount <= 0 || !attributeNames || !attributeTypes || !attributeLengths || primaryKeySize < 0) {
        std::cerr << "Invalid parameters provided to createSchema." << std::endl;
        return nullptr; // Early return on invalid input
    }

    auto *newlyDefinedSchema = new Schema;

    (*newlyDefinedSchema).numAttr = attributeCount;  // Direct assignment, managed externally
    (*newlyDefinedSchema).attrNames = attributeNames; // Direct assignment, managed externally
    (*newlyDefinedSchema).dataTypes = attributeTypes;
    (*newlyDefinedSchema).typeLength = attributeLengths;
    (*newlyDefinedSchema).keySize = primaryKeySize; // Direct assignment, managed externally
    (*newlyDefinedSchema).keyAttrs = primaryKeyAttributes;

    return newlyDefinedSchema;
}

RC freeSchema(Schema *schema) {
    if (schema != nullptr) {
        // Placeholder for future detailed deallocation logic, if needed
        delete schema;
    } else {
        std::cerr << "Attempted to free a nullptr Schema." << std::endl;
    }
    return RC_OK;
}


int getSchemaSize(Schema *schema) {
    if (schema == nullptr) {
        std::cerr << "Error: Schema pointer is null." << std::endl;
        return 0; // Guard clause for null pointer
    }

    int totalSize = 0;
    const int INT_SIZE = sizeof(int); // Size of an integer in bytes

    // Basic structure sizes
    totalSize += INT_SIZE; // For numAttr
    totalSize += (*schema).numAttr * sizeof(int); // For dataTypes array
    totalSize += (*schema).numAttr * INT_SIZE; // For typeLengths array
    totalSize += INT_SIZE; // For keySize
    totalSize += (*schema).keySize * INT_SIZE; // For keyAttrs array

    // Calculating the size required for storing attribute names
    int attrNamesSize = 0;
    for (int i = 0; i < (*schema).numAttr; ++i) {
        if ((*schema).attrNames[i] != nullptr) {
            attrNamesSize += std::strlen((*schema).attrNames[i]); // +1 for null terminator
        } else {
            std::cerr << "Warning: An attribute name is null." << std::endl;
        }
    }
    totalSize += attrNamesSize;

    return totalSize;
}

int lenSlots(Schema *schema) {
    if (!schema) {
        std::cerr << "Schema is null." << std::endl;
        return 0; // Ensure schema is not null.
    }

    // Simplify constants into a single 'baseLength' for readability and maintainability
    const int baseLength = 2 /* square brackets */ + 2 * 5 /* integer sizes for page and slot */ 
                           + 1 /* hyphen */ + 1 /* space */ + 1 /* bracket */;
    
    int totalLength = baseLength; // Start with base length accounting for static elements

    for (int i = 0; i < (*schema).numAttr; ++i) {
        int attributeLength = 0; // To hold the length of individual attribute representations

        // Determine length based on data type
        switch ((*schema).dataTypes[i]) {
            case DT_STRING:
                attributeLength = (*schema).typeLength[i];
                break;
            case DT_INT:
                attributeLength = 5; // Assuming int representation takes up to 5 characters
                break;
            case DT_FLOAT:
                attributeLength = 10; // Assuming float representation takes up to 10 characters
                break;
            case DT_BOOL:
                attributeLength = 5; // "true" or "false", but allocated 5 for consistency
                break;
            default:
                std::cerr << "Unknown data type." << std::endl;
                break;
        }

        // Include the length of the attribute name, and add 1 for the colon and 1 for the bracket
        totalLength += strlen((*schema).attrNames[i]) + attributeLength + 2; 
    }

    return totalLength;
}


// Method to check if table already exists
RC checkTableExists(const char* name) {
    if(std::filesystem::exists(name)) {
        return RC_TABLE_ALREADY_EXISTS;
    }
    return RC_OK;
}

// Method to calculate file and schema sizes
void calculateFileAndSchemaSizes(Schema* schema, int& schemaSize, int& fileSize, int& maxSlots, int& SlotLen) {
    schemaSize = getSchemaSize(schema);
    SlotLen = lenSlots(schema);
    fileSize = static_cast<int>(ceil(static_cast<float>(schemaSize) / PAGE_SIZE));
    maxSlots = static_cast<int>(floor(static_cast<float>(PAGE_SIZE) / static_cast<float>(SlotLen)));
}

// Method to initialize table management data
tableMgmtData* initializeTableMgmtData(int schemaSize, int fileSize, int SlotLen, int maxSlots) {
    tableMgmtData *tInfo = new tableMgmtData();
    (*tInfo).lenTuples = 0;
    (*tInfo).schemaSize = schemaSize;
    (*tInfo).recordStart = fileSize + 1;
    (*tInfo).lenSlots = SlotLen;
    (*tInfo).recordEnd = fileSize + 1;
    (*tInfo).maxSlots = maxSlots;
    (*tInfo).tnodesStart = nullptr;
    return tInfo;
}

// Method to serialize and write table and schema information
RC serializeAndWriteInfo(SM_FileHandle& fh, tableMgmtData* tInfo, Schema* schema) {
    int status;
    char *info_str = serializeTableMgmtInfo(tInfo);
    if ((status = writeBlock(0, &fh, info_str)) != RC_OK)
        return status;

    char *schema_str = serializeSchema(schema);
    if ((status = writeBlock(1, &fh, schema_str)) != RC_OK)
        return status;

    return RC_OK;
}

// Refactored createTable method
RC createTable(char* name, Schema* schema) {
    int status;

    // Check if table already exists
    if ((status = checkTableExists(name)) != RC_OK)
        return status;

    SM_FileHandle fh;

    // Create page file for the new table
    if ((status = createPageFile(name)) != RC_OK)
        return status;

    // Calculate file and schema sizes
    int schemaSize, fileSize, maxSlots, SlotLen;
    calculateFileAndSchemaSizes(schema, schemaSize, fileSize, maxSlots, SlotLen);

    // Open page file
    if ((status = openPageFile(name, &fh)) != RC_OK)
        return status;

    // Ensure capacity for schema and table management information
    if ((status = ensureCapacity((fileSize + 1), &fh)) != RC_OK)
        return status;

    // Initialize table management data
    tableMgmtData* tInfo = initializeTableMgmtData(schemaSize, fileSize, SlotLen, maxSlots);

    // Serialize and write table and schema information
    if ((status = serializeAndWriteInfo(fh, tInfo, schema)) != RC_OK)
        return status;

    // Close page file
    if ((status = closePageFile(&fh)) != RC_OK)
        return status;

    return RC_OK;
}

    // Method to check if table file exists
RC checkTableFileExists(char *name) {
    if (!std::filesystem::exists(name)) {
        return RC_TABLE_NOT_FOUND;
    }
    return RC_OK;
}

// Method to initialize buffer pool and page
void initBufferAndPage(BM_BufferPool *&buffer, BM_PageHandle *&page, char *name) {
    buffer = new BM_BufferPool;
    page = new BM_PageHandle;
    initBufferPool(buffer, name, 3, RS_FIFO, NULL);
    pinPage(buffer, page, 0);
}

// Refactored openTable method
RC openTable(RM_TableData *rel, char *name) {
    // Check if the table file exists
    RC status = checkTableFileExists(name);
    if (status != RC_OK) return status;

    BM_BufferPool *buffer;
    BM_PageHandle *page;
    initBufferAndPage(buffer, page, name);

    tableMgmtData *tInfo = deserializeTableMgmtInfo((*page).data);
    if ((*tInfo).schemaSize < PAGE_SIZE) {
        pinPage(buffer, page, 1);
    }

    (*rel).schema = deserializeSchema((*page).data);
    (*rel).name = name;
    (*tInfo).bm = buffer;
    (*rel).mgmtData = tInfo;

    delete page;
    return RC_OK;
}

    // Method to clean up schema resources
void cleanupSchemaResources(Schema *schema) {
    delete[] (*schema).dataTypes;
    delete[] (*schema).attrNames;
    delete[] (*schema).keyAttrs;
    delete[] (*schema).typeLength;
}

// Refactored closeTable method
RC closeTable(RM_TableData *rel) {
    shutdownBufferPool(static_cast<tableMgmtData *>((*rel).mgmtData)->bm);
    delete static_cast<tableMgmtData *>((*rel).mgmtData);

    cleanupSchemaResources((*rel).schema);
    delete (*rel).schema;

    return RC_OK;
}


    // Method to delete a table file
RC deleteTableFile(char *name) {
    if (!std::filesystem::exists(name)) {
        return RC_TABLE_NOT_FOUND;
    }
    std::filesystem::remove(name);
    return RC_OK;
}

// Refactored deleteTable method using deleteTableFile
RC deleteTable(char *name) {
    return deleteTableFile(name);
}




int getNumTuples(RM_TableData *rel) {
    // Ensure the input pointer and its management data are not null
    if (rel == nullptr || (*rel).mgmtData == nullptr) {
        std::cerr << "Error: Invalid table data provided." << std::endl;
        return -1; // Indicate an error in a way that fits your error handling strategy
    }

    // Safely access and return the number of tuples
    tableMgmtData* managementData = static_cast<tableMgmtData*>((*rel).mgmtData);
    return (*managementData).lenTuples;
}



RC startScan(RM_TableData *rel, RM_ScanHandle *scan, Expr *cond) {
    (*scan).rel = rel; // Link the scan handle to the table

    // Dynamically allocate a RecordInfo instance using the RecordInfo class
    auto rNode = new RecordInfo(cond, static_cast<tableMgmtData*>((*rel).mgmtData)->maxSlots);

    // Initialize the RecordInfo instance with the table's management data
    (*rNode).setCurrentPage(static_cast<tableMgmtData*>((*rel).mgmtData)->recordStart);
    (*rNode).setNumPages(static_cast<tableMgmtData*>((*rel).mgmtData)->recordEnd);
    // Note: Current slot initialized to 0 in constructor, and numSlots is set based on constructor parameter

    // Assign the dynamically allocated RecordInfo to the scan handle's management data
    (*scan).mgmtData = static_cast<void*>(rNode);

    return RC_OK;
}

RC next(RM_ScanHandle *scan, Record *record) {
    RecordInfo *rNode = static_cast<RecordInfo *>((*scan).mgmtData);
    Value *value;
    RC operationStatus;

    (*record).id.slot = (*rNode).getCurrentSlot();
    (*record).id.page = (*rNode).getCurrentPage();

    // Retrieve the record
    operationStatus = getRecord((*scan).rel, (*record).id, record);

    if (operationStatus == RC_RM_NO_MORE_TUPLES) {
        return RC_RM_NO_MORE_TUPLES; // No more tuples to scan
    } else {
        if ((*record).id.tstone == 1) { // If the record is a tombstone
            // Advance to the next slot or page
            if ((*rNode).getCurrentSlot() == (*rNode).getNumSlots() - 1) {
                (*rNode).setCurrentSlot(0);
                (*rNode).setCurrentPage((*rNode).getCurrentPage() + 1);
            } else {
               (*rNode).setCurrentSlot((*rNode).getCurrentSlot() + 1);
            }
            (*scan).mgmtData = rNode;
            return next(scan, record); // Recursively call next to skip this record
        } else {
            // Evaluate the scan condition for the current record
            evalExpr(record, (*scan).rel->schema, (*rNode).getCondition(), &value);
            // Advance to the next slot or page
            if ((*rNode).getCurrentSlot() == (*rNode).getNumSlots() - 1) {
                (*rNode).setCurrentSlot(0);
                (*rNode).setCurrentPage((*rNode).getCurrentPage() + 1);
            } else {
                (*rNode).setCurrentSlot((*rNode).getCurrentSlot() + 1);
            }
            (*scan).mgmtData = rNode;

            // Check if the record matches the condition
            if ((*value).v.boolV) {
                return RC_OK; // The record matches the condition
            } else {
                return next(scan, record); // The record does not match, move to next
            }
        }
    }
}


RC closeScan(RM_ScanHandle *scan) {
    // Validate the scan handle before proceeding
    if (scan!= nullptr) {

    // Safely deallocate any dynamically allocated memory in mgmtData
    if ((*scan).mgmtData) {
        // Assuming RecordInfo is dynamically allocated and stored in mgmtData
      //delete static_cast<RecordInfo*>(scan->mgmtData);
        (*scan).mgmtData = nullptr; // Prevent dangling pointer by setting to nullptr after deletion
    }

    // Reset relation pointer to nullptr as part of scan closure
    (*scan).rel = nullptr;

    return RC_OK;
    }
    else
    {
        return RC_SCAN_HANDLE_NOT_FOUND; // Return an error if the scan handle is null
    }
}


int getRecordSize(Schema *schema) {
    int recordSize = 0;

    for (int i = 0; i < (*schema).numAttr; ++i) {
        switch ((*schema).dataTypes[i]) {
            case DT_STRING:
                recordSize += (*schema).typeLength[i]; // Size for string type length
                break;
            case DT_INT:
                recordSize += sizeof(int); // Size for integer
                break;
            case DT_FLOAT:
                recordSize += sizeof(float); // Size for float
                break;
            case DT_BOOL:
                recordSize += sizeof(bool); // Size for boolean
                break;
            default:
                // Optionally handle unexpected data types
                break;
        }
    }

    return recordSize;
}

RC createRecord(Record** record, Schema* schema) {
    if (record == nullptr || schema == nullptr) {
        return RC_INVALID_INPUT; // Assuming there's a code for invalid input
    }

    try {
        *record = new Record();
        int recordSize = getRecordSize(schema); // Calculate the record size based on the schema
        (*(*record)).data = new char[recordSize](); // Allocate and initialize record data
    } catch (const std::bad_alloc&) {
        return RC_MEMORY_ALLOCATION_FAILURE; // Assuming there's a code for memory allocation failure
    }

    return RC_OK;
}

RC freeRecord(Record* record) {
    if (record != nullptr) {
        // Ensure data pointer is not null before deletion
        if ((*record).data != nullptr) {
            delete[] (*record).data; // Use delete[] to match new[] used for allocation
            (*record).data = nullptr; // Prevent dangling pointer
        }

        delete record; // Delete the record itself
        record = nullptr; // Prevent dangling pointer
    }

    return RC_OK;
}

RC tableInfoToFile(char* name, tableMgmtData* tInfo) {
    if (!std::filesystem::exists(name)) {
        return RC_TABLE_NOT_FOUND;
    }

    SM_FileHandle fh;
    int status = openPageFile(name, &fh);
    if (status != RC_OK) {
        return status;
    }

    char* info_str = serializeTableMgmtInfo(tInfo);
    status = writeBlock(0, &fh, info_str);
    delete[] info_str; // Ensure deletion regardless of the outcome

    if (status != RC_OK) {
        closePageFile(&fh); // Attempt to close the file handle even if write failed
        return status;
    }

    status = closePageFile(&fh);
    return status; // This will return RC_OK if closePageFile succeeded
}



RC insertRecord(RM_TableData* rel, Record* record) {
    BM_PageHandle* page = new BM_PageHandle();
    tableMgmtData* tInfo = static_cast<tableMgmtData*>((*rel).mgmtData);
    int pageNum, slot;
    int caseNum = ((*tInfo).tnodesStart != nullptr) ? 1 : 0;

    switch (caseNum) {
        case 1: // tnodesStart is not null
            pageNum = (*tInfo).tnodesStart->id.page;
            slot = (*tInfo).tnodesStart->id.slot;
            (*tInfo).tnodesStart = (*tInfo).tnodesStart->next;
            break;
        case 0: // tnodesStart is null
            pageNum = (*tInfo).recordEnd;
            slot = (*tInfo).lenTuples - ((pageNum - (*tInfo).recordStart) * (*tInfo).maxSlots);
            
            if (slot == (*tInfo).maxSlots) {
                slot = 0;
                pageNum++;
            }
            (*tInfo).recordEnd = pageNum;
            break;
    }

    (*record).id.page = pageNum;
    (*record).id.slot = slot;

    char* record_str = serializeRecord(record, (*rel).schema);

    pinPage((*tInfo).bm, page, pageNum);
    memcpy((*page).data + (slot * (*tInfo).lenSlots), record_str, strlen(record_str));
    delete[] record_str;

    markDirty((*tInfo).bm, page);
    unpinPage((*tInfo).bm, page);
    forcePage((*tInfo).bm, page);

    (*record).id.tstone = false;
    ((*tInfo).lenTuples)++;
    tableInfoToFile((*rel).name, tInfo);
    delete page;
    return RC_OK;
}


enum TableState {
    HAS_TUPLES,
    NO_TUPLES
};

enum NodeState {
    START_NULL,
    START_NOT_NULL
};
RC deleteRecord(RM_TableData *rel, RID id) {
    tableMgmtData *tInfo = reinterpret_cast<tableMgmtData *>((*rel).mgmtData);
    tombstoneNode *tstone_iter = (*tInfo).tnodesStart;
    TableState tableState = (*tInfo).lenTuples > 0 ? HAS_TUPLES : NO_TUPLES;

    switch (tableState) {
        case HAS_TUPLES: {
            NodeState nodeState = (*tInfo).tnodesStart == nullptr ? START_NULL : START_NOT_NULL;
            switch (nodeState) {
                case START_NULL:
                    (*tInfo).tnodesStart = new tombstoneNode();
                    (*tInfo).tnodesStart->next = nullptr;
                    tstone_iter = (*tInfo).tnodesStart;
                    break;
                case START_NOT_NULL:
                    while ((*tstone_iter).next != nullptr) {
                        tstone_iter = (*tstone_iter).next;
                    }
                    (*tstone_iter).next = new tombstoneNode();
                    tstone_iter = (*tstone_iter).next;
                    (*tstone_iter).next = nullptr;
                    break;
            }
            (*tstone_iter).id.page = id.page;
            (*tstone_iter).id.slot = id.slot;
            (*tstone_iter).id.tstone = 1;
            ((*tInfo).lenTuples)--;
            ((*tInfo).numTnodes)++;
            tableInfoToFile((*rel).name, tInfo);
            break;
        }
        case NO_TUPLES:
            return RC_WRITE_FAILED;
    }

    return RC_OK;
}



    // Initialize Page Handle
BM_PageHandle* initializePageHandle() {
    return static_cast<BM_PageHandle *>(malloc(sizeof(BM_PageHandle)));
}

// Serialize Record
char* serializeRecordWrapper(Record *record, Schema *schema) {
    return serializeRecord(record, schema); // Assuming serializeRecord() returns a dynamically allocated string
}

// Update Page with Record
void updatePageWithRecord(BM_BufferPool *bm, BM_PageHandle *page, int pageNum, int slot, char *record_str, int lenSlots) {
    pinPage(bm, page, pageNum);
    memcpy((*page).data + (slot * lenSlots), record_str, strlen(record_str));
}

// Finalize Update
void finalizeUpdate(BM_BufferPool *bm, BM_PageHandle *page) {
    markDirty(bm, page);
    unpinPage(bm, page);
    forcePage(bm, page);
}

// Refactored updateRecord method
RC updateRecord(RM_TableData *rel, Record *record) {
    BM_PageHandle *page = initializePageHandle();
    if (!page) return RC_MEM_ALLOC_FAIL; // Handle memory allocation failure

    tableMgmtData *tInfo = static_cast<tableMgmtData *>((*rel).mgmtData);
    int pageNum = (*record).id.page, slot = (*record).id.slot;

    char *record_str = serializeRecordWrapper(record, (*rel).schema);
    if (!record_str) { // Handle potential serialization failure or memory allocation failure
        free(page);
        return RC_SERIALIZATION_FAIL;
    }

    updatePageWithRecord((*tInfo).bm, page, pageNum, slot, record_str, (*tInfo).lenSlots);
    delete[] record_str; // Clean up the serialized record string

    finalizeUpdate((*tInfo).bm, page);

    tableInfoToFile((*rel).name, tInfo); // Assuming tableInfoToFile handles its own errors internally

    free(page); // Clean up the page handle
    return RC_OK;
}

    RC getRecord(RM_TableData* rel, RID id, Record* record) {
    tableMgmtData* tInfo = static_cast<tableMgmtData*>((*rel).mgmtData);
    BM_PageHandle* page = new BM_PageHandle();

    int pageNum = id.page, slot = id.slot;

    (*record).id = id; // Simplified assignment
    (*record).id.tstone = 0;

    // Check if tombstone
    tombstoneNode* root = (*tInfo).tnodesStart;
    int tombStoneFlag = 0;
    int tombStoneCount = 0;

    // Using while loop instead of for loop
    int k = 0;
    while (k < (*tInfo).numTnodes) {
        if ((*root).id.page == pageNum && (*root).id.slot == slot) {
            tombStoneFlag = 1;
            (*record).id.tstone = 1;
            break;
        }
        root = (*root).next;
        tombStoneCount++;
        k++;
    }

    // Using switch statement
    switch (tombStoneFlag) {
        case 0: { // Not tombstoned, retrieve the record
            int tupleNumber = (pageNum - (*tInfo).recordStart) * (*tInfo).maxSlots + slot + 1 - tombStoneCount;
            if (tupleNumber > (*tInfo).lenTuples) {
                delete page;
                return RC_RM_NO_MORE_TUPLES;
            }

            pinPage((*tInfo).bm, page, pageNum);
            char* record_str = new char[(*tInfo).lenSlots];
            memcpy(record_str, (*page).data + slot * (*tInfo).lenSlots, (*tInfo).lenSlots);
            unpinPage((*tInfo).bm, page);

            Record* temp_record = deserializeRecord(record_str, rel);

            // Assuming 'record->data' needs to deep copy 'temp_record->data'
            // Specific copying mechanism depends on how 'data' is managed
            (*record).data = (*temp_record).data; // This might need adjustment
            //delete[] record_str;
            delete temp_record;
            break;
        }
        case 1: { // Tombstoned, accessing it is not possible
            //delete page;
            return RC_RECORD_TOMBSTONED;
        }
    }

    delete page;
    return RC_OK;
}


   

    RC getAttr(Record *record, Schema *schema, int attrNum, Value **value) {
    *value = new Value;
    int offset;

    // Find the offset of the attribute in the record based on the schema
    attrOffset(schema, attrNum, &offset);
    char *attributeData = (*record).data + offset;
    (*(*value)).dt = (*schema).dataTypes[attrNum];

    // Directly get the value based on its type
    switch ((*schema).dataTypes[attrNum]) {
        case DT_INT: {
            memcpy(&((*value)->v.intV), attributeData, sizeof(int));
            break;
        }
        case DT_STRING: {
            // Block scope for variables declared within
            int len = (*schema).typeLength[attrNum];
            char *stringValue = new char[len + 1];
            strncpy(stringValue, attributeData, len);
            stringValue[len] = '\0'; // Ensure null-termination
            (*(*value)).v.stringV = stringValue;
            break;
        }
        case DT_FLOAT: {
            memcpy(&((*value)->v.floatV), attributeData, sizeof(float));
            break;
        }
        case DT_BOOL: {
            // Assuming bool1 is a typedef or alias for bool. Adjust as necessary.
            memcpy(&((*value)->v.boolV), attributeData, sizeof(bool));
            break;
        }
        default: {
            // Handle unsupported data types or throw an error
            delete *value; // Clean up allocated Value before returning error
            return RC_ERROR; // Assuming RC_ERROR is defined elsewhere as an error code
        }
    }

    return RC_OK; // Assuming RC_OK is defined elsewhere as a success code
}


  RC setAttr(Record *record, Schema *schema, int attrNum, Value *value) {
    int offset;

    // Find the offset of the attribute in the record based on the schema
    attrOffset(schema, attrNum, &offset);
    char *attributeData = (*record).data + offset;

    // Directly set the value based on its type
    switch ((*schema).dataTypes[attrNum]) {
        case DT_INT: {
            memcpy(attributeData, &((*value).v.intV), sizeof(int));
            break;
        }
        case DT_STRING: {
            // The block ensures that len is only declared within this scope
            int len = (*schema).typeLength[attrNum];
            // Assuming value->v.stringV already points to a properly allocated and null-terminated string
            // Copy only the first (len-1) characters to ensure the string is properly null-terminated
            memcpy(attributeData, (*value).v.stringV, len);
            //attributeData[len - 1] = '\0'; // Ensure null-termination
            break;
        }
        case DT_FLOAT: {
            memcpy(attributeData, &((*value).v.floatV), sizeof(float));
            break;
        }
        case DT_BOOL: {
            memcpy(attributeData, &((*value).v.boolV), sizeof(bool));
            break;
        }
        default: {
            // Handle unsupported data types or throw an error
            return RC_ERROR; // Assuming RC_ERROR is defined elsewhere as an error code
        }
    }

    return RC_OK; // Assuming RC_OK is defined elsewhere as a success code
}