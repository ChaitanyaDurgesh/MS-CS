#include "buffer_mgr.h"
#include "storage_mgr.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>

#ifndef RC_ERROR
#define RC_ERROR 100
#endif

#ifndef RC_PINNED_PAGES_IN_BUFFER
#define RC_PINNED_PAGES_IN_BUFFER 101
#endif

typedef struct Frame {
    PageNumber pageNum;
    bool isDirty;
    int fixCount;
    char *data;
    int lastUsed;
    bool refBit;
} Frame;

typedef struct BufferPool {
    Frame *frames;
    int numPages;
    int readIO;
    int writeIO;
    ReplacementStrategy strategy;
    void *stratData;
    int *pageToFrame;
    int clockHand;
} BufferPool;

static int findFrameToReplace(BufferPool *bp) {
    int i;
    switch (bp->strategy) {
        case RS_FIFO:
            for (i = 0; i < bp->numPages; i++) {
                if (bp->frames[i].fixCount == 0) {
                    return i;
                }
            }
            break;
        case RS_LRU:
            {
                int leastUsed = -1;
                int minLastUsed = INT_MAX;
                for (i = 0; i < bp->numPages; i++) {
                    if (bp->frames[i].fixCount == 0 && bp->frames[i].lastUsed < minLastUsed) {
                        leastUsed = i;
                        minLastUsed = bp->frames[i].lastUsed;
                    }
                }
                return leastUsed;
            }
        case RS_CLOCK:
            {
                int startHand = bp->clockHand;
                do {
                    if (bp->frames[bp->clockHand].fixCount == 0) {
                        if (!bp->frames[bp->clockHand].refBit) {
                            int victim = bp->clockHand;
                            bp->clockHand = (bp->clockHand + 1) % bp->numPages;
                            return victim;
                        }
                        bp->frames[bp->clockHand].refBit = false;
                    }
                    bp->clockHand = (bp->clockHand + 1) % bp->numPages;
                } while (bp->clockHand != startHand);
            }
            break;
        default:
            return -1;
    }
    return -1;
}

RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName, 
                  const int numPages, ReplacementStrategy strategy, void *stratData) {
    if (bm == NULL || pageFileName == NULL || numPages <= 0) {
        return RC_ERROR;
    }

    BufferPool *bp = (BufferPool *)calloc(1, sizeof(BufferPool));
    if (bp == NULL) {
        return RC_ERROR;
    }

    bp->frames = (Frame *)calloc(numPages, sizeof(Frame));
    if (bp->frames == NULL) {
        free(bp);
        return RC_ERROR;
    }

    bp->numPages = numPages;
    bp->strategy = strategy;
    bp->pageToFrame = (int *)malloc(sizeof(int) * numPages);
    if (bp->pageToFrame == NULL) {
        free(bp->frames);
        free(bp);
        return RC_ERROR;
    }

    for (int i = 0; i < numPages; i++) {
        bp->frames[i].pageNum = NO_PAGE;
        bp->frames[i].data = (char *)malloc(PAGE_SIZE);
        if (bp->frames[i].data == NULL) {
            for (int j = 0; j < i; j++) {
                free(bp->frames[j].data);
            }
            free(bp->pageToFrame);
            free(bp->frames);
            free(bp);
            return RC_ERROR;
        }
        bp->pageToFrame[i] = -1;
    }

    bm->pageFile = (char *)malloc(strlen(pageFileName) + 1);
    if (bm->pageFile == NULL) {
        for (int i = 0; i < numPages; i++) {
            free(bp->frames[i].data);
        }
        free(bp->pageToFrame);
        free(bp->frames);
        free(bp);
        return RC_ERROR;
    }
    strcpy(bm->pageFile, pageFileName);

    bm->numPages = numPages;
    bm->strategy = strategy;
    bm->mgmtData = bp;

    return RC_OK;
}

RC shutdownBufferPool(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_ERROR;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    RC rc = forceFlushPool(bm);
    if (rc != RC_OK) {
        return rc;
    }

    for (int i = 0; i < bp->numPages; i++) {
        if (bp->frames[i].fixCount > 0) {
            return RC_PINNED_PAGES_IN_BUFFER;
        }
        free(bp->frames[i].data);
    }

    free(bp->frames);
    free(bp->pageToFrame);
    free(bm->pageFile);
    free(bp);
    bm->mgmtData = NULL;

    return RC_OK;
}

// Force flush pool
RC forceFlushPool(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_ERROR;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    for (int i = 0; i < bp->numPages; i++) {
        if (bp->frames[i].isDirty && bp->frames[i].fixCount == 0) {
            RC rc = forcePage(bm, &(BM_PageHandle){.pageNum = bp->frames[i].pageNum, .data = bp->frames[i].data});
            if (rc != RC_OK) {
                return rc;
            }
        }
    }
    return RC_OK;
}

// Mark page as dirty
RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page) {
    if (bm == NULL || bm->mgmtData == NULL || page == NULL) {
        return RC_ERROR;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    int frameNum = bp->pageToFrame[page->pageNum];
    if (frameNum != -1) {
        bp->frames[frameNum].isDirty = true;
        return RC_OK;
    }
    return RC_ERROR;
}

// Unpin page
RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page) {
    if (bm == NULL || bm->mgmtData == NULL || page == NULL) {
        return RC_ERROR;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    int frameNum = bp->pageToFrame[page->pageNum];
    if (frameNum != -1 && bp->frames[frameNum].fixCount > 0) {
        bp->frames[frameNum].fixCount--;
        return RC_OK;
    }
    return RC_ERROR;
}

// Force page to disk
RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page) {
    if (bm == NULL || bm->mgmtData == NULL || page == NULL) {
        return RC_ERROR;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    int frameNum = bp->pageToFrame[page->pageNum];
    if (frameNum != -1) {
        SM_FileHandle fh;
        RC rc = openPageFile(bm->pageFile, &fh);
        if (rc != RC_OK) return rc;
        
        rc = writeBlock(page->pageNum, &fh, bp->frames[frameNum].data);
        if (rc != RC_OK) {
            closePageFile(&fh);
            return rc;
        }
        
        closePageFile(&fh);
        bp->writeIO++;
        bp->frames[frameNum].isDirty = false;
        return RC_OK;
    }
    return RC_ERROR;
}

// Pin page
RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum) {
    if (bm == NULL || bm->mgmtData == NULL || page == NULL) {
        return RC_ERROR;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    int frameNum = bp->pageToFrame[pageNum];

    if (frameNum != -1) {
        bp->frames[frameNum].fixCount++;
        bp->frames[frameNum].lastUsed = ++(bp->readIO);
        bp->frames[frameNum].refBit = true;
        page->pageNum = pageNum;
        page->data = bp->frames[frameNum].data;
        return RC_OK;
    }

    frameNum = findFrameToReplace(bp);
    if (frameNum == -1) return RC_ERROR;

    if (bp->frames[frameNum].isDirty) {
        RC rc = forcePage(bm, &(BM_PageHandle){.pageNum = bp->frames[frameNum].pageNum, .data = bp->frames[frameNum].data});
        if (rc != RC_OK) return rc;
    }

    SM_FileHandle fh;
    RC rc = openPageFile(bm->pageFile, &fh);
    if (rc != RC_OK) return rc;

    rc = ensureCapacity(pageNum + 1, &fh);
    if (rc != RC_OK) {
        closePageFile(&fh);
        return rc;
    }

    rc = readBlock(pageNum, &fh, bp->frames[frameNum].data);
    closePageFile(&fh);
    if (rc != RC_OK) return rc;

    bp->readIO++;
    if (bp->frames[frameNum].pageNum != NO_PAGE) {
        bp->pageToFrame[bp->frames[frameNum].pageNum] = -1;
    }
    bp->frames[frameNum].pageNum = pageNum;
    bp->frames[frameNum].isDirty = false;
    bp->frames[frameNum].fixCount = 1;
    bp->frames[frameNum].lastUsed = bp->readIO;
    bp->frames[frameNum].refBit = true;
    bp->pageToFrame[pageNum] = frameNum;

    page->pageNum = pageNum;
    page->data = bp->frames[frameNum].data;

    return RC_OK;
}

// Get frame contents
PageNumber *getFrameContents(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return NULL;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    PageNumber *contents = (PageNumber *)malloc(sizeof(PageNumber) * bp->numPages);
    if (contents == NULL) {
        return NULL;
    }

    for (int i = 0; i < bp->numPages; i++) {
        contents[i] = bp->frames[i].pageNum;
    }
    return contents;
}

// Get dirty flags
bool *getDirtyFlags(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return NULL;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    bool *flags = (bool *)malloc(sizeof(bool) * bp->numPages);
    if (flags == NULL) {
        return NULL;
    }

    for (int i = 0; i < bp->numPages; i++) {
        flags[i] = bp->frames[i].isDirty;
    }
    return flags;
}

// Get fix counts
int *getFixCounts(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return NULL;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    int *counts = (int *)malloc(sizeof(int) * bp->numPages);
    if (counts == NULL) {
        return NULL;
    }

    for (int i = 0; i < bp->numPages; i++) {
        counts[i] = bp->frames[i].fixCount;
    }
    return counts;
}

// Get number of read IOs
int getNumReadIO(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return -1;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    return bp->readIO;
}

// Get number of write IOs
int getNumWriteIO(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return -1;
    }

    BufferPool *bp = (BufferPool *)bm->mgmtData;
    return bp->writeIO;
}